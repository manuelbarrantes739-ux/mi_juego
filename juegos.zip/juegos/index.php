<?php
declare(strict_types=1);

header('Location: public/index.html', true, 302);
exit;
