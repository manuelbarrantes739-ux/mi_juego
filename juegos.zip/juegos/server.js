require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const path = require('path');
const { initializeDatabase } = require('./src/db');
const api = require('./src/routes');

const app = express();
const port = Number(process.env.PORT || 3000);

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET debe tener al menos 32 caracteres.');
}

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'data:'],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: '100kb' }));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads'), { maxAge: '1d' }));
app.use('/api', api);
app.use(express.static(path.join(__dirname, 'public')));

app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && 'body' in err) {
    return res.status(400).json({ error: 'El cuerpo JSON no es válido.' });
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'La imagen supera el límite de 3 MB.' });
  }
  if (err.message === 'Formato de imagen no permitido.') {
    return res.status(415).json({ error: err.message });
  }
  console.error(err);
  return res.status(500).json({ error: 'Ocurrió un error interno.' });
});

initializeDatabase()
  .then(() => app.listen(port, () => {
    console.log(`Logo Hunter listo en http://localhost:${port}`);
  }))
  .catch((error) => {
    console.error('No fue posible iniciar la aplicación:', error.message);
    process.exitCode = 1;
  });
