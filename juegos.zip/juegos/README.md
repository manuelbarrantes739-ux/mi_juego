# LOGO HUNTER — Terminator Edition

Juego arcade web adaptable con lluvia de emblemas, control Canvas, puntuación y niveles; el panel administrativo permite gestionar instituciones, emblemas, dificultad y estadísticas.

## Requisitos

- Node.js 18 o posterior.
- MySQL 8 (el esquema usa `ROW_NUMBER()` en el procedimiento incluido).
- La base y las tablas creadas a partir de `db_juegos.sql`.

## Instalación

1. En phpMyAdmin o en la consola MySQL, importa `db_juegos.sql`. El script crea `logo_hunter_db` y los datos de ejemplo.
2. Copia `.env.example` a `.env` y configura `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` y `JWT_SECRET`. Usa un secreto aleatorio de al menos 32 caracteres.
3. Para crear el primer administrador de forma segura, define temporalmente `ADMIN_USER` y `ADMIN_PASSWORD` en `.env` (mínimo 12 caracteres); se insertará mediante bcrypt al iniciar el servidor si ese usuario aún no existe. Retira ambas variables después del primer inicio.
4. Ejecuta `npm install` y luego `npm start`.
5. Abre `http://localhost:3000`.

Para desarrollo usa `npm run dev`. No se incluyen credenciales predeterminadas. `npm run admin:create` permite añadir otros administradores usando las mismas dos variables de entorno.

Al usar Apache/XAMPP, abre `http://localhost/juegos/`: `index.php` redirige a la portada en `public/` y `.htaccess` desactiva el listado de archivos y bloquea la lectura pública de `.env`. `public/api.php` conecta el registro, inicio de sesión, partidas, instituciones y el panel administrativo directamente con MySQL. Para habilitar el panel, configura `ADMIN_USER` y `ADMIN_PASSWORD` en `.env`, y ejecuta desde PowerShell `C:\xampp\php\php.exe C:\xampp\htdocs\juegos\scripts\create-admin.php`; después borra esos dos valores de `.env`. El panel permite cambiar por separado el nombre de la institución, el nombre que aparece en el juego y la imagen del escudo. `npm start` continúa disponible para el servidor Node.

La gestión de instituciones también está disponible como interfaz independiente en `http://localhost/juegos/public/instituciones.html` (o `/instituciones.html` con el servidor Node). La página tiene su propio formulario de acceso administrativo y permite crear, editar, activar y eliminar instituciones; eliminar las desactiva para conservar el historial de partidas.

## Juego

El jugador se registra con nombres, apellidos, institución, nombre de usuario y contraseña. La contraseña se protege con bcrypt; el token de sesión permanece en el mismo navegador durante 12 horas y se puede renovar al iniciar sesión. Las partidas y estadísticas se guardan en MySQL. Flechas izquierda/derecha, A/D o arrastrar controlan la canasta; espacio o Escape pausa. El botón de pantalla completa solicita el permiso al navegador.

La misión avanza por niveles al alcanzar la meta de puntaje acumulada de cada etapa. Al superar una meta, la partida se pausa y muestra una pantalla de transición con el nombre del siguiente nivel, su meta y los cambios de dificultad; pulsa **Continuar nivel** para seguir. El HUD muestra el nombre del nivel y el progreso hacia su meta. Cada nivel incrementa la velocidad de caída, reduce el intervalo de aparición y permite más emblemas simultáneos; desde el nivel 2 aparecen emblemas negativos y su frecuencia aumenta en los niveles posteriores. Tras completar los niveles configurados, la dificultad continúa aumentando.

Los emblemas se cargan desde `logotipos`. En el panel administrativo, entra a **Instituciones** y pulsa **Editar logo** para cambiar tanto la imagen como el nombre que aparece durante la partida; los dos campos se guardan junto con el registro. Los escudos de Perú Birf, Politécnico, Comercio 32, José Antonio Encinas, INA 91, José María Arguedas, Las Mercedes y Pedro Vilcapaza están instalados en `public/uploads/peru-birf.png`, `public/uploads/politecnico.png`, `public/uploads/comercio32.png`, `public/uploads/encinas.png`, `public/uploads/ina91.png`, `public/uploads/jose-maria-arguedas.png`, `public/uploads/mercedes.png` y `public/uploads/vilcapaza.png`, respectivamente. Si no hay filas activas, el juego conserva ocho emblemas de respaldo; los que aún no tienen escudo real usan el distintivo temporal. Las imágenes se pueden sustituir en el panel por archivos PNG, JPG o WEBP de hasta 3 MB.

## Base de datos existente

El juego usa las tablas `administradores`, `instituciones`, `usuarios`, `logotipos`, `niveles`, `partidas`, `progreso_jugadores` y `configuracion` definidas por `db_juegos.sql`. La eliminación de una institución desde el panel es lógica (cambia su estado a inactivo) para preservar las relaciones e historial de partidas. Las categorías y puntajes predeterminados corresponden a las siete categorías del esquema.

## Rutas principales

- `GET /api/bootstrap`, `GET /api/rankings`
- `POST /api/students/register`, `POST /api/students/login`, `GET /api/students/me`, `GET /api/students/history`
- `POST /api/games`
- `POST /api/admin/login`
- `GET/POST/PUT/DELETE /api/admin/institutions`, `POST /api/admin/upload`
- `GET/PUT /api/admin/levels`, `PUT /api/admin/settings`, `GET /api/admin/stats`

La API administrativa requiere JWT con rol de administrador; la API del jugador requiere JWT de jugador. Los formularios del servidor validan datos y las consultas usan parámetros SQL. El inicio de sesión está limitado por IP.
