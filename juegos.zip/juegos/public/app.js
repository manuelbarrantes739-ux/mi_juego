(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const placeholder = './assets/placeholder.svg';
  const peruBirfLogo = './uploads/peru-birf.png';
  const politecnicoLogo = './uploads/politecnico.png';
  const encinasLogo = './uploads/encinas.png';
  const ina91Logo = './uploads/ina91.png';
  const mercedesLogo = './uploads/mercedes.png';
  const arguedasLogo = './uploads/jose-maria-arguedas.png';
  const comercio32Logo = './uploads/comercio32.png';
  const vilcapazaLogo = './uploads/vilcapaza.png';
  const logoAssetVersion = 'levels-transparent-bg-20261104';
  const phpApiUrl = new URL('./api.php', document.currentScript.src).href;
  const usePhpApi = window.location.pathname.includes('/juegos/');
  const initialInstitutions = [
    { id_institucion: 1, nombre: 'Perú Birf' },
    { id_institucion: 2, nombre: 'Politécnico' },
    { id_institucion: 3, nombre: 'José Antonio Encinas' },
    { id_institucion: 4, nombre: 'Las Mercedes' },
    { id_institucion: 5, nombre: 'Comercio 32' },
    { id_institucion: 6, nombre: 'INA 91' },
    { id_institucion: 7, nombre: 'José María Arguedas' },
    { id_institucion: 8, nombre: 'Pedro Vilcapaza' }
  ];
  const playerTokenKey = 'logoHunterPlayerToken';
  const playerDataKey = 'logoHunterPlayer';
  const adminTokenKey = 'logoHunterAdminToken';
  function readStoredPlayer() {
    const storedPlayer = localStorage.getItem(playerDataKey);
    if (!storedPlayer) return null;
    try {
      const player = JSON.parse(storedPlayer);
      if (player && typeof player === 'object' && !Array.isArray(player)) return player;
    } catch (error) {
      if (!(error instanceof SyntaxError)) throw error;
    }
    localStorage.removeItem(playerDataKey);
    return null;
  }
  const defaultLevels = [
    { numero_nivel: 1, nombre: 'Principiante', puntaje_objetivo: 100, velocidad_caida: 1, frecuencia_logotipos: 1500, cantidad_maxima_logotipos: 5 },
    { numero_nivel: 2, nombre: 'Aprendiz', puntaje_objetivo: 250, velocidad_caida: 1.3, frecuencia_logotipos: 1200, cantidad_maxima_logotipos: 7 },
    { numero_nivel: 3, nombre: 'Intermedio', puntaje_objetivo: 500, velocidad_caida: 1.6, frecuencia_logotipos: 1000, cantidad_maxima_logotipos: 9 },
    { numero_nivel: 4, nombre: 'Avanzado', puntaje_objetivo: 800, velocidad_caida: 2, frecuencia_logotipos: 800, cantidad_maxima_logotipos: 12 },
    { numero_nivel: 5, nombre: 'Experto', puntaje_objetivo: 1200, velocidad_caida: 2.5, frecuencia_logotipos: 600, cantidad_maxima_logotipos: 15 },
    { numero_nivel: 6, nombre: 'Terminator', puntaje_objetivo: 2000, velocidad_caida: 3, frecuencia_logotipos: 450, cantidad_maxima_logotipos: 20 }
  ];
  const fallbackLogos = [
    { nombre: 'Perú Birf', institucion: 'Perú Birf', categoria: 'COMUN', tipo: 'POSITIVO', puntaje: 10, imagen: peruBirfLogo, probabilidad: 50 },
    { nombre: 'Politécnico', institucion: 'Politécnico', categoria: 'ESPECIAL', tipo: 'POSITIVO', puntaje: 25, imagen: politecnicoLogo, probabilidad: 38 },
    { nombre: 'José Antonio Encinas', institucion: 'José Antonio Encinas', categoria: 'DORADO', tipo: 'POSITIVO', puntaje: 50, imagen: encinasLogo, probabilidad: 24 },
    { nombre: 'Las Mercedes', institucion: 'Las Mercedes', categoria: 'COMUN', tipo: 'POSITIVO', puntaje: 10, imagen: mercedesLogo, probabilidad: 50 },
    { nombre: 'Comercio 32', institucion: 'Comercio 32', categoria: 'LEGENDARIO', tipo: 'POSITIVO', puntaje: 100, imagen: comercio32Logo, probabilidad: 15 },
    { nombre: 'INA 91', institucion: 'INA 91', categoria: 'CONTAMINADO', tipo: 'NEGATIVO', puntaje: -10, imagen: ina91Logo, probabilidad: 26 },
    { nombre: 'José María Arguedas', institucion: 'José María Arguedas', categoria: 'PELIGROSO', tipo: 'NEGATIVO', puntaje: -25, imagen: arguedasLogo, probabilidad: 18 },
    { nombre: 'Pedro Vilcapaza', institucion: 'Pedro Vilcapaza', categoria: 'PENALIZACION', tipo: 'NEGATIVO', puntaje: -50, imagen: vilcapazaLogo, probabilidad: 12 }
  ];

  function logoImageUrl(path) {
    const url = new URL(path || placeholder, window.location.href);
    url.searchParams.set('v', logoAssetVersion);
    return url.href;
  }

  const state = {
    institutions: [], logos: fallbackLogos, levels: defaultLevels, config: { tiempo_partida: 120, sonido_activo: 1 },
    studentToken: localStorage.getItem(playerTokenKey) || '',
    player: readStoredPlayer(),
    adminToken: sessionStorage.getItem(adminTokenKey) || '',
    screen: 'welcome', score: 0, level: 1, caught: 0, missed: 0, remaining: 120,
    best: 0, active: false, paused: false, levelTransition: false, saved: false, lastFrame: 0, spawnElapsed: 0,
    items: [], particles: [], keys: new Set(), basket: { x: 0, width: 104, height: 45 },
    soundOn: true, audio: null, toastTimer: 0, animationId: 0,
    adminInstitutions: [], settings: {}
  };

  async function api(url, options = {}, token = '') {
    const headers = new Headers(options.headers || {});
    if (token) headers.set('Authorization', `Bearer ${token}`);
    if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
    const requestUrl = usePhpApi
      ? `${phpApiUrl}?path=${encodeURIComponent(url.replace(/^\/api\/?/, ''))}`
      : url;
    const response = await fetch(requestUrl, { ...options, headers });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Error del servidor (${response.status}).`);
    return payload;
  }

  function showScreen(name) {
    const activeScreen = `screen-${name}`;
    $$('.screen').forEach((section) => {
      const isActive = section.id === activeScreen;
      section.classList.toggle('active', isActive);
      section.setAttribute('aria-hidden', String(!isActive));
    });
    state.screen = name;
    const section = $(`#${activeScreen}`);
    const heading = section?.querySelector('h1, h2') || section?.querySelector('.game-title') || section;
    if (heading) {
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
    }
    window.scrollTo({
      top: 0,
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'
    });
    if (name === 'ranking') loadRanking();
    if (name === 'menu') {
      $('#menu-player').textContent = state.player?.username || 'PILOTO';
    }
    if (name === 'admin') loadAdminTab('institutions');
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[char]);
  }

  async function loadBootstrap() {
    try {
      const data = await api('/api/bootstrap');
      state.institutions = data.institutions || [];
      state.logos = data.logos?.length ? data.logos : fallbackLogos;
      state.levels = data.levels?.length ? data.levels : defaultLevels;
      state.config = data.config || state.config;
      state.remaining = Number(state.config.tiempo_partida) || 120;
      state.soundOn = Boolean(Number(state.config.sonido_activo));
      renderInstitutionOptions();
      updateSoundButton();
    } catch (error) {
      state.institutions = initialInstitutions;
      renderInstitutionOptions();
      showNotice(`No se pudo consultar la base de datos. Se muestran las instituciones iniciales; el registro requiere MySQL activo. ${error.message}`, 'warning');
    }
  }

  function renderInstitutionOptions() {
    const select = $('#register-form select[name="id_institucion"]');
    if (!select) return;
    const options = state.institutions.map((item) =>
      `<option value="${Number(item.id_institucion)}">${escapeHtml(item.nombre)}</option>`
    ).join('');
    select.innerHTML = `<option value="">Selecciona tu institución</option>${options}`;
    if (!state.institutions.length) {
      select.innerHTML = '<option value="">No hay instituciones disponibles</option>';
    }
  }

  function showNotice(message, type = 'info') {
    let node = $('#global-notice');
    if (!node) {
      node = document.createElement('div');
      node.id = 'global-notice';
      node.setAttribute('role', 'status');
      node.style.cssText = 'position:fixed;z-index:20;right:18px;top:88px;max-width:min(420px,90vw);padding:12px 16px;background:#171d24;border:1px solid #49545d;color:#dce1e4;font:12px Inter,Arial,sans-serif;box-shadow:0 12px 30px #0008';
      document.body.appendChild(node);
    }
    node.style.borderColor = type === 'warning' ? '#e5aa50' : '#49545d';
    node.textContent = message;
    clearTimeout(node.noticeTimeout);
    node.noticeTimeout = setTimeout(() => node.remove(), 5000);
  }

  function getConfiguredLevels() {
    return state.levels.length ? state.levels : defaultLevels;
  }

  function getTargetScore(levelNumber = state.level) {
    const levels = getConfiguredLevels();
    const configuredCount = levels.length;
    let target = 0;
    for (let number = 1; number <= Math.min(levelNumber, configuredCount); number += 1) {
      const configured = levels.find((level) => Number(level.numero_nivel) === number) || levels[number - 1];
      target = Math.max(target + 100, Number(configured?.puntaje_objetivo) || 0);
    }
    if (levelNumber > configuredCount) {
      const increment = Math.max(100, Math.round(target * 0.6));
      target += (levelNumber - configuredCount) * increment;
    }
    return target;
  }

  function getLevelSettings(levelNumber = state.level) {
    const levels = getConfiguredLevels();
    let settings = levels.find((level) => Number(level.numero_nivel) === 1) || levels[0] || defaultLevels[0];
    for (let number = 2; number <= levelNumber; number += 1) {
      const configured = levels.find((level) => Number(level.numero_nivel) === number) || levels[levels.length - 1];
      settings = {
        ...configured,
        nombre: number > levels.length ? `${configured.nombre} +${number - levels.length}` : configured.nombre,
        velocidad_caida: Math.min(7, Math.max(
          Number(configured.velocidad_caida) || 1,
          Number(settings.velocidad_caida) + 0.12
        )),
        frecuencia_logotipos: Math.max(250, Math.min(
          Number(configured.frecuencia_logotipos) || 1200,
          Number(settings.frecuencia_logotipos) - 50
        )),
        cantidad_maxima_logotipos: Math.min(30, Math.max(
          Number(configured.cantidad_maxima_logotipos) || 5,
          Number(settings.cantidad_maxima_logotipos) + 1
        ))
      };
    }
    return settings;
  }

  function setupGameCanvas() {
    const canvas = $('#game-canvas');
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.floor(rect.width * ratio));
    canvas.height = Math.max(1, Math.floor(rect.height * ratio));
    const context = canvas.getContext('2d');
    context.setTransform(ratio, 0, 0, ratio, 0, 0);
    state.basket.x = rect.width / 2;
    state.canvasWidth = rect.width;
    state.canvasHeight = rect.height;
  }

  function beginGame() {
    if (!state.studentToken || !state.player) {
      showScreen('register');
      return;
    }
    state.score = 0;
    state.level = 1;
    state.caught = 0;
    state.missed = 0;
    state.remaining = Number(state.config.tiempo_partida) || 120;
    state.best = Number(state.player.record_personal || 0);
    state.items = [];
    state.particles = [];
    state.active = true;
    state.paused = false;
    state.levelTransition = false;
    state.saved = false;
    state.lastFrame = 0;
    state.spawnElapsed = 0;
    $('#game-player').textContent = `// ${state.player.username}`;
    $('#pause-overlay').classList.add('hidden');
    $('#level-overlay').classList.add('hidden');
    showScreen('game');
    requestAnimationFrame(() => {
      setupGameCanvas();
      updateHud();
      cancelAnimationFrame(state.animationId);
      state.animationId = requestAnimationFrame(gameLoop);
    });
  }

  function pauseGame() {
    if (!state.active || state.paused) return;
    state.paused = true;
    $('#pause-overlay').classList.remove('hidden');
    $('#resume-button').focus();
  }

  function resumeGame() {
    if (!state.active || !state.paused || state.levelTransition) return;
    state.paused = false;
    $('#pause-overlay').classList.add('hidden');
    $('#pause-button').focus();
    state.lastFrame = performance.now();
    state.animationId = requestAnimationFrame(gameLoop);
  }

  function continueLevel() {
    if (!state.active || !state.paused || !state.levelTransition) return;
    state.levelTransition = false;
    state.paused = false;
    $('#level-overlay').classList.add('hidden');
    state.lastFrame = performance.now();
    $('#pause-button').focus();
    state.animationId = requestAnimationFrame(gameLoop);
  }

  function finishGame(won, abandoned = false) {
    if (!state.active || state.saved) return;
    state.active = false;
    state.paused = false;
    state.saved = true;
    cancelAnimationFrame(state.animationId);
    const elapsed = Math.max(0, Math.round((Number(state.config.tiempo_partida || 120) - state.remaining)));
    const result = abandoned ? 'ABANDONADA' : won ? 'VICTORIA' : 'DERROTA';
    $('#result-title').innerHTML = won ? 'MISIÓN <span>COMPLETADA</span>' : abandoned ? 'MISIÓN <span>FINALIZADA</span>' : 'SEÑAL <span>PERDIDA</span>';
    $('#result-eyebrow').textContent = won ? 'OBJETIVO ALCANZADO // EXCELENTE TRABAJO' : 'REPORTE DE MISIÓN // SISTEMA REGISTRADO';
    $('#result-description').textContent = won ? 'Superaste todos los niveles. Tu desempeño quedó registrado.' : 'La simulación terminó. Ajusta tu estrategia y vuelve a intentarlo.';
    $('#result-mark').classList.toggle('defeat', !won);
    $('#result-score').textContent = state.score.toLocaleString('es-PE');
    $('#result-level').textContent = String(state.level);
    $('#result-caught').textContent = String(state.caught);
    $('#result-record').textContent = Math.max(state.best, state.score).toLocaleString('es-PE');
    $('#save-status').textContent = 'Guardando resultado…';
    showScreen('result');
    api('/api/games', {
      method: 'POST',
      body: JSON.stringify({
        puntaje_final: state.score,
        nivel_alcanzado: state.level,
        logotipos_atrapados: state.caught,
        logotipos_perdidos: state.missed,
        tiempo_jugado: elapsed,
        resultado: result
      })
    }, state.studentToken).then(() => {
      $('#save-status').textContent = '✓ Resultado guardado en tu historial.';
      state.best = Math.max(state.best, state.score);
      if (state.player) {
        state.player.record_personal = state.best;
        localStorage.setItem(playerDataKey, JSON.stringify(state.player));
      }
    }).catch((error) => {
      $('#save-status').textContent = `No se pudo guardar el resultado: ${error.message}`;
    });
  }

  function weightedLogo() {
    const level = state.level;
    const candidates = state.logos.filter((logo) => {
      if (level === 1) return logo.tipo === 'POSITIVO';
      if (level === 2) return logo.tipo === 'POSITIVO' || logo.tipo === 'NEGATIVO';
      if (level === 3) return logo.tipo === 'POSITIVO' || logo.tipo === 'NEGATIVO';
      return true;
    });
    const eligible = candidates.length ? candidates : fallbackLogos;
    const pool = eligible.map((logo) => {
      let weight = Math.max(1, Number(logo.probabilidad) || 30);
      if (level === 1 && logo.tipo === 'POSITIVO') weight *= 2.2;
      if (level === 2 && logo.tipo === 'NEGATIVO') weight *= 0.35;
      if (level >= 3 && logo.tipo === 'NEGATIVO') weight *= 1 + (level - 3) * 0.2;
      if (state.level > state.levels.length && logo.categoria === 'LEGENDARIO') weight *= 1.3;
      return { logo, weight };
    });
    const total = pool.reduce((sum, item) => sum + item.weight, 0);
    let random = Math.random() * total;
    for (const item of pool) {
      random -= item.weight;
      if (random <= 0) return item.logo;
    }
    return pool[pool.length - 1].logo;
  }

  function spawnLogo() {
    const logo = weightedLogo();
    const size = 43 + Math.random() * 18;
    const width = state.canvasWidth || 600;
    const image = new Image();
    image.src = logoImageUrl(logo.imagen);
    image.onerror = () => {
      if (image.src.endsWith(placeholder)) return;
      image.src = placeholder;
    };
    state.items.push({
      logo, image, x: size / 2 + Math.random() * Math.max(1, width - size),
      y: -size - 12, size, rotation: (Math.random() - 0.5) * 0.32,
      angle: (Math.random() - 0.5) * 0.2,
      speed: (1.05 + Math.random() * 0.95) * Number(getLevelSettings().velocidad_caida || 1) *
        (Number(logo.velocidad) || 1),
      sway: Math.random() * Math.PI * 2,
      swaySpeed: 0.7 + Math.random() * 1.2
    });
  }

  function drawBasket(context, width, height, time) {
    const basketWidth = state.basket.width;
    const basketHeight = state.basket.height;
    const x = Math.max(basketWidth / 2 + 5, Math.min(width - basketWidth / 2 - 5, state.basket.x));
    state.basket.x = x;
    const y = height - basketHeight - 22;
    context.save();
    context.translate(x, y);
    const glow = context.createRadialGradient(0, 0, 4, 0, 0, 85);
    glow.addColorStop(0, 'rgba(243,59,66,0.18)');
    glow.addColorStop(1, 'rgba(243,59,66,0)');
    context.fillStyle = glow;
    context.fillRect(-90, -35, 180, 90);
    context.shadowColor = '#f33b42aa';
    context.shadowBlur = 14;
    context.fillStyle = '#262d34';
    context.strokeStyle = '#c4ccd1';
    context.lineWidth = 2;
    context.beginPath();
    context.moveTo(-basketWidth / 2, -basketHeight);
    context.lineTo(basketWidth / 2, -basketHeight);
    context.lineTo(basketWidth / 2 - 10, 0);
    context.lineTo(-basketWidth / 2 + 10, 0);
    context.closePath();
    context.fill();
    context.stroke();
    context.shadowBlur = 0;
    context.strokeStyle = '#f33b42';
    context.lineWidth = 3;
    context.beginPath();
    context.moveTo(-basketWidth / 2 - 5, -basketHeight - 2);
    context.lineTo(basketWidth / 2 + 5, -basketHeight - 2);
    context.stroke();
    context.strokeStyle = '#84909a';
    context.lineWidth = 1;
    for (let i = -3; i <= 3; i += 1) {
      context.beginPath();
      context.moveTo(i * 12, -basketHeight + 4);
      context.lineTo(i * 10, -4);
      context.stroke();
    }
    context.fillStyle = '#e9edf0';
    context.font = '700 10px "DM Mono", monospace';
    context.textAlign = 'center';
    context.fillText('LH', 0, -11);
    context.globalAlpha = 0.4 + (Math.sin(time / 300) + 1) * 0.15;
    context.fillStyle = '#f33b42';
    context.fillRect(-basketWidth / 2 - 3, -basketHeight - 6, 6, 4);
    context.fillRect(basketWidth / 2 - 3, -basketHeight - 6, 6, 4);
    context.restore();
  }

  function drawLogo(context, item, time) {
    const negative = item.logo.tipo === 'NEGATIVO';
    const color = negative ? '#f33b42' :
      item.logo.categoria === 'DORADO' || item.logo.categoria === 'LEGENDARIO' ? '#ffca66' : '#6de8a7';
    const x = item.x + Math.sin(time / 600 * item.swaySpeed + item.sway) * 15;
    item.drawX = x;
    context.save();
    context.translate(x, item.y);
    context.rotate(item.rotation + Math.sin(time / 900 + item.sway) * item.angle);
    if (item.image.complete && item.image.naturalWidth) {
      context.drawImage(item.image, -item.size / 2, -item.size / 2, item.size, item.size);
    } else {
      context.fillStyle = color;
      context.font = `700 ${Math.round(item.size * 0.28)}px "Barlow Condensed", sans-serif`;
      context.textAlign = 'center';
      context.textBaseline = 'middle';
      context.fillText((item.logo.nombre || 'LH').slice(0, 2).toUpperCase(), 0, -1);
    }
    context.fillStyle = '#edf0f2';
    context.font = '9px "DM Mono", monospace';
    context.textAlign = 'center';
    context.textBaseline = 'top';
    context.shadowColor = '#000';
    context.shadowBlur = 5;
    context.fillText((item.logo.nombre || 'EMBLEMA').slice(0, 17), 0, item.size / 2 + 4);
    context.fillStyle = color;
    context.font = 'bold 10px "DM Mono", monospace';
    context.fillText(`${Number(item.logo.puntaje) > 0 ? '+' : ''}${item.logo.puntaje}`, 0, item.size / 2 + 15);
    context.restore();
  }

  function addCaptureEffect(x, y, positiveHit, points) {
    const color = positiveHit ? '#62e8a4' : '#ff5158';
    for (let i = 0; i < 16; i += 1) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.2 + Math.random() * 4;
      state.particles.push({
        x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        life: 0.45 + Math.random() * 0.4, maxLife: 0.85,
        size: 2 + Math.random() * 3, color
      });
    }
    showToast(`${Number(points) > 0 ? '+' : ''}${points} PTS`, positiveHit);
    playTone(positiveHit ? 720 : 175, 0.12, positiveHit ? 'sine' : 'sawtooth');
  }

  function showToast(message, positiveHit) {
    const toast = $('#game-toast');
    toast.textContent = message;
    toast.classList.toggle('positive-toast', positiveHit);
    toast.classList.toggle('negative-toast', !positiveHit);
    toast.classList.add('show');
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => toast.classList.remove('show'), 700);
  }

  function updateHud() {
    $('#hud-score').textContent = String(state.score).padStart(5, '0');
    $('#hud-level').textContent = String(state.level).padStart(2, '0');
    $('#hud-level-name').textContent = getLevelSettings().nombre || `Nivel ${state.level}`;
    $('#hud-caught').textContent = String(state.caught).padStart(2, '0');
    $('#hud-record').textContent = String(Math.max(state.best, state.score)).padStart(5, '0');
    const totalSeconds = Math.ceil(state.remaining);
    $('#hud-time').textContent = `${String(Math.floor(totalSeconds / 60)).padStart(2, '0')}:${String(totalSeconds % 60).padStart(2, '0')}`;
    const goal = getTargetScore();
    const previous = state.level === 1 ? 0 : getTargetScore(state.level - 1);
    const levelGoal = Math.max(1, goal - previous);
    const levelProgress = Math.max(0, state.score - previous);
    const progress = Math.max(0, Math.min(100, (levelProgress / levelGoal) * 100));
    $('#goal-label').textContent = `${levelProgress} / ${levelGoal}`;
    $('#progress-bar').style.width = `${progress}%`;
  }

  function maybeAdvanceLevel() {
    if (state.score < getTargetScore()) return;
    state.level += 1;
    state.paused = true;
    state.levelTransition = true;
    state.items = [];
    state.spawnElapsed = 0;
    const settings = getLevelSettings();
    const goal = getTargetScore();
    $('#level-overlay-number').textContent = String(state.level).padStart(2, '0');
    $('#level-overlay-name').textContent = settings.nombre || `Nivel ${state.level}`;
    $('#level-overlay-details').textContent =
      `CAÍDA ×${Number(settings.velocidad_caida).toFixed(1)}  ·  ${Number(settings.cantidad_maxima_logotipos)} EMBLEMAS  ·  APARICIÓN CADA ${(Number(settings.frecuencia_logotipos) / 1000).toFixed(2)} S`;
    $('#level-overlay-goal').textContent = `NUEVA META: ${Math.max(0, goal - state.score)} PUNTOS PARA COMPLETAR EL NIVEL`;
    $('#level-overlay').classList.remove('hidden');
    $('#continue-level-button').focus();
    playTone(980, 0.2, 'sine');
    updateHud();
  }

  function gameLoop(timestamp) {
    if (!state.active || state.paused) return;
    const canvas = $('#game-canvas');
    const context = canvas?.getContext('2d');
    if (!context) {
      finishGame(false);
      return;
    }
    const width = state.canvasWidth;
    const height = state.canvasHeight;
    const delta = Math.min(0.04, state.lastFrame ? (timestamp - state.lastFrame) / 1000 : 0);
    state.lastFrame = timestamp;
    state.remaining = Math.max(0, state.remaining - delta);
    const moveSpeed = Math.max(260, width * 0.72) * delta;
    if (state.keys.has('ArrowLeft') || state.keys.has('KeyA')) state.basket.x -= moveSpeed;
    if (state.keys.has('ArrowRight') || state.keys.has('KeyD')) state.basket.x += moveSpeed;

    state.spawnElapsed += delta * 1000;
    const levelSettings = getLevelSettings();
    const interval = Math.max(230, Number(levelSettings.frecuencia_logotipos || 1200));
    while (state.spawnElapsed >= interval) {
      state.spawnElapsed -= interval;
      if (state.items.length < Math.min(24, Number(levelSettings.cantidad_maxima_logotipos || 7))) spawnLogo();
    }

    context.clearRect(0, 0, width, height);
    drawGrid(context, width, height);
    const basketTop = height - state.basket.height - 22 - state.basket.height;
    for (let index = state.items.length - 1; index >= 0; index -= 1) {
      const item = state.items[index];
      item.y += item.speed * 90 * delta;
      drawLogo(context, item, timestamp);
      if (item.y + item.size / 2 >= basketTop && item.y - item.size / 2 <= basketTop + state.basket.height &&
          Math.abs(item.drawX - state.basket.x) < state.basket.width / 2 + item.size * 0.25) {
        const points = Number(item.logo.puntaje) || 0;
        state.score += points;
        state.caught += 1;
        addCaptureEffect(item.drawX, item.y, points >= 0, points);
        state.items.splice(index, 1);
        maybeAdvanceLevel();
        updateHud();
        if (state.levelTransition) break;
        continue;
      }
      if (item.y - item.size / 2 > height) {
        state.items.splice(index, 1);
        state.missed += 1;
      }
    }
    drawBasket(context, width, height, timestamp);
    drawParticles(context, delta);
    updateHud();
    if (state.remaining <= 0) {
      finishGame(state.level > getConfiguredLevels().length);
      return;
    }
    state.animationId = requestAnimationFrame(gameLoop);
  }

  function drawGrid(context, width, height) {
    context.save();
    context.strokeStyle = 'rgba(118,132,145,0.07)';
    context.lineWidth = 1;
    const step = 38;
    for (let x = (width % step); x < width; x += step) {
      context.beginPath();
      context.moveTo(x, 0);
      context.lineTo(x, height);
      context.stroke();
    }
    for (let y = (height % step); y < height; y += step) {
      context.beginPath();
      context.moveTo(0, y);
      context.lineTo(width, y);
      context.stroke();
    }
    context.restore();
  }

  function drawParticles(context, delta) {
    for (let i = state.particles.length - 1; i >= 0; i -= 1) {
      const particle = state.particles[i];
      particle.life -= delta;
      if (particle.life <= 0) {
        state.particles.splice(i, 1);
        continue;
      }
      particle.x += particle.vx;
      particle.y += particle.vy;
      particle.vy += 0.06;
      context.globalAlpha = Math.min(1, particle.life / particle.maxLife);
      context.fillStyle = particle.color;
      context.beginPath();
      context.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      context.fill();
    }
    context.globalAlpha = 1;
  }

  function ensureAudio() {
    if (!state.audio) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) state.audio = new AudioContext();
    }
    if (state.audio?.state === 'suspended') state.audio.resume().catch(() => {});
  }

  function playTone(frequency, duration, type = 'sine') {
    if (!state.soundOn) return;
    try {
      ensureAudio();
      if (!state.audio) return;
      const oscillator = state.audio.createOscillator();
      const gain = state.audio.createGain();
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.055, state.audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, state.audio.currentTime + duration);
      oscillator.connect(gain);
      gain.connect(state.audio.destination);
      oscillator.start();
      oscillator.stop(state.audio.currentTime + duration);
    } catch (error) {
      console.warn('El sonido no está disponible en este navegador.', error);
    }
  }

  function updateSoundButton() {
    $('#sound-toggle').textContent = state.soundOn ? '♫' : '♪';
    $('#sound-toggle').setAttribute('aria-pressed', String(state.soundOn));
  }

  async function loadRanking() {
    const container = $('#ranking-rows');
    container.innerHTML = '<p class="empty-state">Conectando con el ranking...</p>';
    container.setAttribute('aria-busy', 'true');
    try {
      const rows = await api('/api/rankings');
      if (!rows.length) {
        container.innerHTML = '<p class="empty-state">Aún no hay partidas registradas. ¡Sé el primero!</p>';
        return;
      }
      container.innerHTML = rows.map((row, index) => `
        <div class="ranking-row">
          <strong class="ranking-pos">${String(index + 1).padStart(2, '0')}</strong>
          <span><span class="ranking-name">${escapeHtml(row.nombre_usuario)}</span><span class="ranking-school">${escapeHtml(row.institucion || 'Sin institución')}</span></span>
          <span class="ranking-level">NV. ${Number(row.nivel_maximo) || 1}</span>
          <strong class="ranking-score">${Number(row.mejor_puntaje || 0).toLocaleString('es-PE')}</strong>
        </div>`).join('');
    } catch (error) {
      container.innerHTML = `<p class="empty-state">${escapeHtml(error.message)}<br>Comprueba la conexión con el servidor.</p>`;
    } finally {
      container.setAttribute('aria-busy', 'false');
    }
  }

  async function showHistory() {
    const panel = $('#history-panel');
    panel.classList.remove('hidden');
    panel.innerHTML = '<p class="empty-state">Cargando historial...</p>';
    if (!state.studentToken) {
      panel.innerHTML = '<p class="empty-state">Registra tu perfil antes de consultar el historial.</p>';
      return;
    }
    try {
      const [profile, games] = await Promise.all([
        api('/api/students/me', {}, state.studentToken),
        api('/api/students/history', {}, state.studentToken)
      ]);
      state.player = { ...state.player, ...profile };
      panel.innerHTML = `<div class="admin-toolbar"><b>${escapeHtml(profile.nombres)} ${escapeHtml(profile.apellidos)}</b><span>RÉCORD ${Number(profile.record_personal || 0)} · NIVEL ${Number(profile.nivel_maximo || 1)}</span></div>
        ${games.length ? `<div class="history-list">${games.map((game) => `<div class="history-row"><span>${new Date(game.fecha_inicio).toLocaleDateString('es-PE')}</span><b>${Number(game.puntaje_final).toLocaleString('es-PE')} PTS</b><span>NV. ${Number(game.nivel_alcanzado)}</span><span>${Number(game.logotipos_atrapados)} capturas</span></div>`).join('')}</div>` : '<p class="empty-state">Todavía no tienes misiones registradas.</p>'}`;
    } catch (error) {
      if (error.message.includes('sesión expiró') || error.message.includes('Inicia sesión')) {
        panel.innerHTML = `${escapeHtml(error.message)} <button class="small-button" id="history-login">INICIAR SESIÓN</button>`;
        $('#history-login')?.addEventListener('click', () => showScreen('student-login'));
      } else {
        panel.textContent = error.message;
      }
    }
  }

  async function handleStudentRegister(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const errorNode = $('#register-error');
    errorNode.textContent = '';
    const formData = new FormData(form);
    const body = Object.fromEntries(formData.entries());
    body.id_institucion = Number(body.id_institucion);
    try {
      const result = await api('/api/students/register', { method: 'POST', body: JSON.stringify(body) });
      state.studentToken = result.token;
      state.player = result.player;
      localStorage.setItem(playerTokenKey, result.token);
      localStorage.setItem(playerDataKey, JSON.stringify(result.player));
      form.reset();
      showScreen('menu');
    } catch (error) {
      errorNode.textContent = error.message;
    }
  }

  async function handleStudentLogin(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const errorNode = $('#student-login-error');
    errorNode.textContent = '';
    try {
      const result = await api('/api/students/login', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(new FormData(form).entries()))
      });
      state.studentToken = result.token;
      state.player = result.player;
      localStorage.setItem(playerTokenKey, result.token);
      localStorage.setItem(playerDataKey, JSON.stringify(result.player));
      form.reset();
      showScreen('menu');
    } catch (error) {
      errorNode.textContent = error.message;
    }
  }

  async function handleAdminLogin(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const errorNode = $('#admin-login-error');
    errorNode.textContent = '';
    try {
      const result = await api('/api/admin/login', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(new FormData(form).entries()))
      });
      state.adminToken = result.token;
      sessionStorage.setItem(adminTokenKey, result.token);
      form.reset();
      showScreen('admin');
    } catch (error) {
      errorNode.textContent = error.message;
    }
  }

  async function loadAdminTab(tab) {
    $$('.admin-tab').forEach((button) => button.classList.toggle('active', button.dataset.adminTab === tab));
    const content = $('#admin-content');
    content.innerHTML = '<p class="empty-state">Cargando panel…</p>';
    try {
      if (tab === 'institutions') await renderAdminInstitutions(content);
      if (tab === 'levels') await renderAdminLevels(content);
      if (tab === 'stats') await renderAdminStats(content);
    } catch (error) {
      if (error.message.includes('sesión expiró') || error.message.includes('Inicia sesión')) {
        state.adminToken = '';
        sessionStorage.removeItem(adminTokenKey);
        showScreen('admin-login');
      }
      content.innerHTML = `<p class="empty-state">${escapeHtml(error.message)}</p>`;
    }
  }

  function categoryScore(category) {
    return ({ COMUN: 10, ESPECIAL: 25, DORADO: 50, LEGENDARIO: 100, CONTAMINADO: -10, PELIGROSO: -25, PENALIZACION: -50 })[category] || 10;
  }

  function categoryType(category) {
    return ['COMUN', 'ESPECIAL', 'DORADO', 'LEGENDARIO'].includes(category) ? 'POSITIVO' : 'NEGATIVO';
  }

  async function renderAdminInstitutions(content) {
    state.adminInstitutions = await api('/api/admin/institutions', {}, state.adminToken);
    const rows = state.adminInstitutions.map((item) => `
      <tr>
        <td><img src="${escapeHtml(logoImageUrl(item.imagen))}" alt=""></td>
        <td>${escapeHtml(item.nombre)}<small class="admin-secondary-name">JUEGO: ${escapeHtml(item.nombre_logotipo || item.nombre)}</small></td><td>${escapeHtml(item.codigo || '—')}</td>
        <td>${escapeHtml(item.categoria || '—')} ${item.puntaje == null ? '' : `(${Number(item.puntaje) > 0 ? '+' : ''}${Number(item.puntaje)})`}</td>
        <td><span class="status-chip ${item.estado === 'ACTIVO' ? '' : 'off'}">● ${item.estado === 'ACTIVO' ? 'ACTIVA' : 'INACTIVA'}</span></td>
        <td><div class="table-actions"><button class="small-button edit-institution" data-id="${Number(item.id_institucion)}">EDITAR LOGO</button><button class="small-button toggle-institution" data-id="${Number(item.id_institucion)}" data-state="${escapeHtml(item.estado)}">${item.estado === 'ACTIVO' ? 'DESACTIVAR' : 'ACTIVAR'}</button></div></td>
      </tr>`).join('');
    content.innerHTML = `
      <div class="admin-toolbar"><span>${state.adminInstitutions.length} REGISTROS DE INSTITUCIÓN</span><div class="institution-toolbar-actions"><a class="button button-ghost" href="./instituciones.html">ABRIR GESTIÓN INDEPENDIENTE ↗</a><button class="button button-primary" id="new-institution">+ NUEVA INSTITUCIÓN</button></div></div>
      <div class="table-wrap"><table class="admin-table"><thead><tr><th>EMBLEMA</th><th>INSTITUCIÓN / NOMBRE EN EL JUEGO</th><th>CÓDIGO</th><th>CATEGORÍA / PUNTOS</th><th>ESTADO</th><th>ACCIONES</th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="empty-state">Sin instituciones registradas.</td></tr>'}</tbody></table></div>
      <form class="panel admin-form hidden" id="institution-form">
        <input type="hidden" name="id_institucion"><input type="hidden" name="imagen" value="${placeholder}">
        <label>NOMBRE DE LA INSTITUCIÓN<input name="nombre" maxlength="150" required></label>
        <label>NOMBRE DEL LOGO EN EL JUEGO<input name="nombre_logotipo" maxlength="150" required><small>Este nombre aparece durante la partida.</small></label>
        <label>CÓDIGO<input name="codigo" maxlength="30"></label>
        <label>CATEGORÍA<select name="categoria">${['COMUN','ESPECIAL','DORADO','LEGENDARIO','CONTAMINADO','PELIGROSO','PENALIZACION'].map((value) => `<option>${value}</option>`).join('')}</select></label>
        <label>PUNTAJE<input name="puntaje" type="number" step="1" required value="10"></label>
        <label>VELOCIDAD<input name="velocidad" type="number" min=".25" max="5" step=".05" value="1"></label>
        <label>FRECUENCIA / PROBABILIDAD (%)<input name="probabilidad" type="number" min="1" max="100" step="1" value="50"></label>
        <label>CAMBIAR IMAGEN DEL LOGO<input name="archivo" type="file" accept="image/png,image/jpeg,image/webp"><small>Sube una imagen PNG, JPG o WEBP de hasta 3 MB.</small></label>
        <label>VISTA PREVIA<img class="upload-preview" src="${placeholder}" alt="Emblema temporal" style="width:44px;height:44px;object-fit:contain"></label>
        <label>ESTADO<select name="estado"><option value="ACTIVO">ACTIVA</option><option value="INACTIVO">INACTIVA</option></select></label>
        <div class="admin-submit"><button class="button button-ghost" type="button" id="cancel-institution">CANCELAR</button> <button class="button button-primary" type="submit">GUARDAR CAMBIOS</button></div>
      </form>`;
    $('#new-institution', content).addEventListener('click', () => openInstitutionForm(null));
    $$('.edit-institution', content).forEach((button) => button.addEventListener('click', () => {
      const item = state.adminInstitutions.find((row) => row.id_institucion === Number(button.dataset.id));
      openInstitutionForm(item);
    }));
    $$('.toggle-institution', content).forEach((button) => button.addEventListener('click', () => toggleInstitution(button)));
    $('#cancel-institution', content).addEventListener('click', () => $('#institution-form', content).classList.add('hidden'));
    $('#institution-form', content).addEventListener('submit', saveInstitution);
    $('#institution-form [name="categoria"]', content).addEventListener('change', (event) => {
      $('#institution-form [name="puntaje"]', content).value = String(categoryScore(event.target.value));
    });
    $('#institution-form [name="archivo"]', content).addEventListener('change', previewUpload);
  }

  function openInstitutionForm(item) {
    const form = $('#institution-form');
    form.classList.remove('hidden');
    form.reset();
    form.elements.id_institucion.value = item?.id_institucion || '';
    form.elements.nombre.value = item?.nombre || '';
    form.elements.nombre_logotipo.value = item?.nombre_logotipo || item?.nombre || '';
    form.elements.codigo.value = item?.codigo || '';
    form.elements.categoria.value = item?.categoria || 'COMUN';
    form.elements.puntaje.value = item?.puntaje ?? 10;
    form.elements.velocidad.value = item?.velocidad ?? 1;
    form.elements.probabilidad.value = item?.probabilidad ?? 50;
    form.elements.estado.value = item?.estado || 'ACTIVO';
    form.elements.imagen.value = item?.imagen || placeholder;
    $('.upload-preview', form).src = logoImageUrl(item?.imagen);
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async function previewUpload(event) {
    const file = event.target.files?.[0];
    const form = event.target.form;
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 3 * 1024 * 1024) {
      event.target.value = '';
      showNotice('Usa una imagen PNG, JPG o WEBP de hasta 3 MB.', 'warning');
      return;
    }
    $('.upload-preview', form).src = URL.createObjectURL(file);
  }

  async function toggleInstitution(event) {
    const id = Number(event.currentTarget.dataset.id);
    const item = state.adminInstitutions.find((row) => Number(row.id_institucion) === id);
    if (!item) return;
    const active = item.estado !== 'ACTIVO';
    try {
      const payload = {
        nombre: item.nombre, codigo: item.codigo || '',
        nombre_logotipo: item.nombre_logotipo || item.nombre,
        categoria: item.categoria || 'COMUN', tipo: categoryType(item.categoria || 'COMUN'),
        puntaje: Number(item.puntaje ?? 10), velocidad: Number(item.velocidad || 1),
        probabilidad: Number(item.probabilidad || 50), imagen: item.imagen || placeholder,
        estado: active ? 'ACTIVO' : 'INACTIVO'
      };
      await api(`/api/admin/institutions/${id}`, { method: 'PUT', body: JSON.stringify(payload) }, state.adminToken);
      await loadAdminTab('institutions');
      showNotice(active ? 'Institución activada.' : 'Institución desactivada.');
    } catch (error) {
      showNotice(error.message, 'warning');
    }
  }

  async function saveInstitution(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const submit = $('button[type="submit"], .admin-submit button.button-primary', form);
    const originalText = submit.textContent;
    submit.disabled = true;
    submit.textContent = 'GUARDANDO…';
    try {
      let image = form.elements.imagen.value || placeholder;
      const file = form.elements.archivo.files?.[0];
      if (file) {
        const uploadData = new FormData();
        uploadData.append('imagen', file);
        const response = await api('/api/admin/upload', { method: 'POST', body: uploadData }, state.adminToken);
        image = response.imagen;
      }
      const category = form.elements.categoria.value;
      const body = {
        nombre: form.elements.nombre.value.trim(),
        nombre_logotipo: form.elements.nombre_logotipo.value.trim(),
        codigo: form.elements.codigo.value.trim(),
        categoria: category,
        tipo: categoryType(category),
        puntaje: Number(form.elements.puntaje.value),
        velocidad: Number(form.elements.velocidad.value),
        probabilidad: Number(form.elements.probabilidad.value),
        imagen: image,
        estado: form.elements.estado.value
      };
      const id = form.elements.id_institucion.value;
      await api(id ? `/api/admin/institutions/${id}` : '/api/admin/institutions', {
        method: id ? 'PUT' : 'POST',
        body: JSON.stringify(body)
      }, state.adminToken);
      await loadAdminTab('institutions');
      showNotice('Institución guardada correctamente.');
    } catch (error) {
      showNotice(error.message, 'warning');
    } finally {
      submit.disabled = false;
      submit.textContent = originalText;
    }
  }

  async function renderAdminLevels(content) {
    const data = await api('/api/admin/levels', {}, state.adminToken);
    state.settings = data.config || {};
    const levels = data.levels?.length ? data.levels : defaultLevels;
    content.innerHTML = `
      <form class="panel admin-form" id="settings-form">
        <label>TIEMPO DE PARTIDA (SEG)<input name="tiempo_partida" type="number" min="30" max="600" value="${Number(state.settings.tiempo_partida || 120)}" required></label>
        <label>VELOCIDAD BASE<input name="velocidad_base" type="number" min=".25" max="5" step=".1" value="${Number(state.settings.velocidad_base || 1)}" required></label>
        <label>DIFICULTAD<select name="dificultad_general">${['FACIL','MEDIO','DIFICIL'].map((value) => `<option ${state.settings.dificultad_general === value ? 'selected' : ''}>${value}</option>`).join('')}</select></label>
        <label>SONIDO<select name="sonido_activo"><option value="1" ${Number(state.settings.sonido_activo) ? 'selected' : ''}>ACTIVADO</option><option value="0" ${!Number(state.settings.sonido_activo) ? 'selected' : ''}>DESACTIVADO</option></select></label>
        <div class="admin-submit"><button class="button button-primary">GUARDAR CONFIGURACIÓN</button></div>
      </form>
      <div class="levels-grid">${levels.map((level) => `
        <form class="level-card level-form" data-number="${Number(level.numero_nivel)}">
          <h3>NIVEL ${String(level.numero_nivel).padStart(2, '0')}</h3>
          <label>NOMBRE<input name="nombre" maxlength="100" value="${escapeHtml(level.nombre)}" required></label>
          <label>PUNTAJE OBJETIVO<input name="puntaje_objetivo" type="number" min="1" max="1000000" value="${Number(level.puntaje_objetivo)}" required></label>
          <label>VELOCIDAD DE CAÍDA<input name="velocidad_caida" type="number" min=".25" max="10" step=".1" value="${Number(level.velocidad_caida)}" required></label>
          <label>FRECUENCIA (MS)<input name="frecuencia_logotipos" type="number" min="250" max="10000" value="${Number(level.frecuencia_logotipos)}" required></label>
          <label>EMBLEMAS SIMULTÁNEOS<input name="cantidad_maxima_logotipos" type="number" min="1" max="50" value="${Number(level.cantidad_maxima_logotipos)}" required></label>
          <button class="small-button">GUARDAR NIVEL</button>
        </form>`).join('')}</div>`;
    $('#settings-form', content).addEventListener('submit', saveSettings);
    $$('.level-form', content).forEach((form) => form.addEventListener('submit', saveLevel));
  }

  async function saveSettings(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const body = Object.fromEntries(new FormData(form).entries());
    body.tiempo_partida = Number(body.tiempo_partida);
    body.velocidad_base = Number(body.velocidad_base);
    body.sonido_activo = body.sonido_activo === '1';
    try {
      await api('/api/admin/settings', { method: 'PUT', body: JSON.stringify(body) }, state.adminToken);
      showNotice('Configuración general guardada.');
    } catch (error) {
      showNotice(error.message, 'warning');
    }
  }

  async function saveLevel(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const body = Object.fromEntries(new FormData(form).entries());
    for (const key of ['puntaje_objetivo', 'frecuencia_logotipos', 'cantidad_maxima_logotipos']) body[key] = Number(body[key]);
    body.velocidad_caida = Number(body.velocidad_caida);
    try {
      await api(`/api/admin/levels/${form.dataset.number}`, { method: 'PUT', body: JSON.stringify(body) }, state.adminToken);
      showNotice(`Nivel ${form.dataset.number} actualizado.`);
    } catch (error) {
      showNotice(error.message, 'warning');
    }
  }

  async function renderAdminStats(content) {
    const data = await api('/api/admin/stats', {}, state.adminToken);
    const totals = data.totals || {};
    content.innerHTML = `
      <div class="stats-grid">
        <article class="stat-card"><small>JUGADORES REGISTRADOS</small><strong>${Number(totals.jugadores || 0).toLocaleString('es-PE')}</strong></article>
        <article class="stat-card"><small>MISIONES JUGADAS</small><strong>${Number(totals.partidas || 0).toLocaleString('es-PE')}</strong></article>
        <article class="stat-card"><small>INSTITUCIONES ACTIVAS</small><strong>${Number(totals.instituciones || 0).toLocaleString('es-PE')}</strong></article>
      </div>
      <div class="section-heading" style="text-align:left;margin:24px 0 12px"><span class="eyebrow">MAYORES PUNTAJES</span></div>
      <div class="table-wrap"><table class="admin-table"><thead><tr><th>PILOTO</th><th>INSTITUCIÓN</th><th>RÉCORD</th><th>NIVEL</th></tr></thead><tbody>
      ${(data.leaders || []).map((leader) => `<tr><td>${escapeHtml(leader.nombre_usuario)}</td><td>${escapeHtml(leader.institucion || '—')}</td><td>${Number(leader.mejor_puntaje).toLocaleString('es-PE')}</td><td>${Number(leader.nivel_maximo)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty-state">Aún no hay partidas registradas.</td></tr>'}
      </tbody></table></div>`;
  }

  function bindEvents() {
    $$('[data-screen]').forEach((button) => button.addEventListener('click', (event) => {
      event.preventDefault();
      showScreen(button.dataset.screen);
    }));
    $('#register-form').addEventListener('submit', handleStudentRegister);
    $('#student-login-form').addEventListener('submit', handleStudentLogin);
    $('#admin-login-form').addEventListener('submit', handleAdminLogin);
    $('#begin-game').addEventListener('click', beginGame);
    $('#pause-button').addEventListener('click', pauseGame);
    $('#resume-button').addEventListener('click', resumeGame);
    $('#continue-level-button').addEventListener('click', continueLevel);
    $('#quit-button').addEventListener('click', () => finishGame(false, true));
    $('#exit-game-button').addEventListener('click', () => finishGame(false, true));
    $('#history-button').addEventListener('click', showHistory);
    $('#admin-logout').addEventListener('click', () => {
      state.adminToken = '';
      sessionStorage.removeItem(adminTokenKey);
      showScreen('welcome');
    });
    $$('.admin-tab').forEach((button) => button.addEventListener('click', () => loadAdminTab(button.dataset.adminTab)));
    $('#sound-toggle').addEventListener('click', () => {
      state.soundOn = !state.soundOn;
      updateSoundButton();
      if (state.soundOn) playTone(640, 0.08);
    });
    $('#fullscreen-button').addEventListener('click', async () => {
      try {
        if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
        else await document.exitFullscreen();
      } catch (error) {
        showNotice('El navegador no permitió activar pantalla completa.', 'warning');
      }
    });
    window.addEventListener('keydown', (event) => {
      if (['ArrowLeft', 'ArrowRight', ' '].includes(event.key) &&
          ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return;
      if (event.key === 'Escape' && state.active && !state.paused) pauseGame();
      if (event.key === ' ' && state.active) {
        event.preventDefault();
        state.paused ? resumeGame() : pauseGame();
      }
      state.keys.add(event.code);
    });
    window.addEventListener('keyup', (event) => state.keys.delete(event.code));
    window.addEventListener('blur', () => state.keys.clear());
    window.addEventListener('resize', () => {
      if (state.active && !state.paused && state.screen === 'game') setupGameCanvas();
    });
    const canvas = $('#game-canvas');
    canvas.addEventListener('pointerdown', (event) => {
      canvas.setPointerCapture?.(event.pointerId);
      moveBasketToPointer(event);
    });
    canvas.addEventListener('pointermove', (event) => {
      if (event.buttons || event.pointerType === 'touch') moveBasketToPointer(event);
    });
  }

  function moveBasketToPointer(event) {
    const rect = $('#game-canvas').getBoundingClientRect();
    state.basket.x = event.clientX - rect.left;
  }

  async function init() {
    bindEvents();
    await loadBootstrap();
    if (state.studentToken && state.player) {
      try {
        const profile = await api('/api/students/me', {}, state.studentToken);
        state.player = { ...state.player, ...profile, username: profile.nombre_usuario };
        localStorage.setItem(playerDataKey, JSON.stringify(state.player));
        showScreen('menu');
      } catch (error) {
        state.studentToken = '';
        localStorage.removeItem(playerTokenKey);
        showScreen('welcome');
      }
    }
  }

  init();
})();
