<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function respond(int $status, $data): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function environment(string $key, string $fallback = ''): string
{
    $value = getenv($key);
    if ($value !== false) {
        return $value;
    }

    static $fileValues = null;
    if ($fileValues === null) {
        $fileValues = [];
        $envFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';
        if (is_file($envFile)) {
            foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                    continue;
                }
                [$name, $entry] = explode('=', $line, 2);
                $fileValues[trim($name)] = trim(trim($entry), "\"'");
            }
        }
    }

    return $fileValues[$key] ?? $fallback;
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = environment('DB_HOST', '127.0.0.1');
    $port = environment('DB_PORT', '3306');
    $name = environment('DB_NAME', 'logo_hunter_db');
    $user = environment('DB_USER', 'root');
    $password = environment('DB_PASSWORD');
    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4",
        $user,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    return $pdo;
}

function requestBody(): array
{
    $body = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($body) ? $body : [];
}

function bearerToken(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$header && function_exists('getallheaders')) {
        $headers = getallheaders();
        $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }
    return preg_match('/^Bearer\s+(.+)$/i', $header, $matches) ? $matches[1] : '';
}

function tokenFor(int $id, string $role): string
{
    $secret = environment('JWT_SECRET');
    if (strlen($secret) < 32) {
        respond(500, ['error' => 'Configura JWT_SECRET con al menos 32 caracteres en el archivo .env.']);
    }
    $base64 = static function (string $value): string {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    };
    $issued = time();
    $header = $base64(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload = $base64(json_encode([
        'sub' => (string) $id,
        'role' => $role,
        'iat' => $issued,
        'exp' => $issued + 43200,
    ]));
    $signature = $base64(hash_hmac('sha256', "{$header}.{$payload}", $secret, true));
    return "{$header}.{$payload}.{$signature}";
}

function authenticatedId(string $requiredRole): int
{
    $parts = explode('.', bearerToken());
    if (count($parts) !== 3) {
        respond(401, ['error' => 'Inicia sesión para continuar.']);
    }
    [$header, $payload, $signature] = $parts;
    $secret = environment('JWT_SECRET');
    $expected = rtrim(strtr(base64_encode(hash_hmac('sha256', "{$header}.{$payload}", $secret, true)), '+/', '-_'), '=');
    if ($secret === '' || !hash_equals($expected, $signature)) {
        respond(401, ['error' => 'La sesión no es válida. Inicia sesión nuevamente.']);
    }
    $decoded = base64_decode(strtr($payload, '-_', '+/'));
    $claims = json_decode($decoded ?: '', true);
    if (!is_array($claims) || ($claims['role'] ?? '') !== $requiredRole ||
        (int) ($claims['exp'] ?? 0) <= time() || (int) ($claims['sub'] ?? 0) < 1) {
        respond(401, ['error' => 'La sesión expiró o no tiene permisos.']);
    }
    $id = (int) $claims['sub'];
    if ($requiredRole === 'admin') {
        $check = database()->prepare(
            "SELECT id_administrador FROM administradores
             WHERE id_administrador = ? AND estado = 'ACTIVO' LIMIT 1"
        );
        $check->execute([$id]);
        if (!$check->fetch()) {
            respond(403, ['error' => 'La cuenta administrativa está inactiva.']);
        }
    }
    return $id;
}

function cleanedString(array $body, string $key, int $maximum): string
{
    $value = $body[$key] ?? '';
    return is_string($value) ? mb_substr(trim($value), 0, $maximum, 'UTF-8') : '';
}

function enforceLoginRateLimit(): void
{
    $file = sys_get_temp_dir() . DIRECTORY_SEPARATOR .
        'logo-hunter-login-' . hash('sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown') . '.json';
    $handle = @fopen($file, 'c+');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        if (is_resource($handle)) {
            fclose($handle);
        }
        respond(503, ['error' => 'No se pudo verificar el límite de inicio de sesión.']);
    }

    $contents = stream_get_contents($handle);
    $attempts = json_decode($contents ?: '[]', true);
    if (!is_array($attempts)) {
        $attempts = [];
    }
    $cutoff = time() - 900;
    $attempts = array_values(array_filter($attempts, static function ($time) use ($cutoff): bool {
        return is_int($time) && $time > $cutoff;
    }));
    if (count($attempts) >= 10) {
        flock($handle, LOCK_UN);
        fclose($handle);
        respond(429, ['error' => 'Demasiados intentos. Espera unos minutos.']);
    }

    $attempts[] = time();
    rewind($handle);
    $written = ftruncate($handle, 0) && fwrite($handle, json_encode($attempts)) !== false && fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    if (!$written) {
        respond(503, ['error' => 'No se pudo registrar el intento de inicio de sesión.']);
    }
}

function validLogoData(array $body): ?array
{
    $categories = [
        'COMUN' => 'POSITIVO',
        'ESPECIAL' => 'POSITIVO',
        'DORADO' => 'POSITIVO',
        'LEGENDARIO' => 'POSITIVO',
        'CONTAMINADO' => 'NEGATIVO',
        'PELIGROSO' => 'NEGATIVO',
        'PENALIZACION' => 'NEGATIVO',
    ];
    $category = strtoupper(cleanedString($body, 'categoria', 20));
    $type = strtoupper(cleanedString($body, 'tipo', 20));
    $score = filter_var($body['puntaje'] ?? null, FILTER_VALIDATE_INT);
    $image = cleanedString($body, 'imagen', 255);
    if (!isset($categories[$category]) || $type !== $categories[$category] ||
        $score === false || abs($score) > 10000) {
        return null;
    }
    if (!preg_match(
        '~^(?:assets/placeholder\.svg|uploads/(?:[a-f0-9]{32}\.(?:png|jpg|webp)|(?:comercio32|encinas|ina91|jose-maria-arguedas|mercedes|peru-birf|politecnico|vilcapaza)\.png))$~i',
        $image
    )) {
        return null;
    }

    $speed = filter_var($body['velocidad'] ?? 1, FILTER_VALIDATE_FLOAT);
    $probability = filter_var($body['probabilidad'] ?? 50, FILTER_VALIDATE_INT);
    $speed = $speed === false ? 1.0 : $speed;
    $probability = $probability === false ? 50 : $probability;
    if ($speed < 0.25 || $speed > 5 || $probability < 1 || $probability > 100) {
        return null;
    }

    return [
        'categoria' => $category,
        'tipo' => $type,
        'puntaje' => $score,
        'velocidad' => $speed,
        'probabilidad' => $probability,
        'imagen' => $image,
    ];
}

function institutionPayload(array $body): ?array
{
    $name = cleanedString($body, 'nombre', 150);
    $logoName = cleanedString($body, 'nombre_logotipo', 150);
    $code = cleanedString($body, 'codigo', 30);
    $state = ($body['estado'] ?? 'ACTIVO') === 'INACTIVO' ? 'INACTIVO' : 'ACTIVO';
    $logo = validLogoData($body);
    if ($name === '' || $logo === null) {
        return null;
    }
    return [
        'nombre' => $name,
        'nombre_logotipo' => $logoName !== '' ? $logoName : $name,
        'codigo' => $code !== '' ? $code : null,
        'estado' => $state,
        'logo' => $logo,
    ];
}

function updateInstitution(PDO $db, int $id, array $data): void
{
    $db->beginTransaction();
    try {
        $update = $db->prepare(
            'UPDATE instituciones SET nombre = ?, codigo = ?, estado = ? WHERE id_institucion = ?'
        );
        $update->execute([$data['nombre'], $data['codigo'], $data['estado'], $id]);
        if ($update->rowCount() === 0) {
            $exists = $db->prepare('SELECT id_institucion FROM instituciones WHERE id_institucion = ?');
            $exists->execute([$id]);
            if (!$exists->fetch()) {
                $db->rollBack();
                respond(404, ['error' => 'Institución no encontrada.']);
            }
        }

        $findLogo = $db->prepare(
            'SELECT id_logotipo FROM logotipos WHERE id_institucion = ? ORDER BY id_logotipo LIMIT 1'
        );
        $findLogo->execute([$id]);
        $existing = $findLogo->fetch();
        $logo = $data['logo'];
        if ($existing) {
            $saveLogo = $db->prepare(
                'UPDATE logotipos SET nombre = ?, imagen = ?, categoria = ?, tipo = ?,
                 puntaje = ?, velocidad = ?, probabilidad = ?, estado = ? WHERE id_logotipo = ?'
            );
            $saveLogo->execute([
                $data['nombre_logotipo'], $logo['imagen'], $logo['categoria'], $logo['tipo'],
                $logo['puntaje'], $logo['velocidad'], $logo['probabilidad'], $data['estado'],
                $existing['id_logotipo'],
            ]);
            $disableOthers = $db->prepare(
                'UPDATE logotipos SET estado = ? WHERE id_institucion = ? AND id_logotipo <> ?'
            );
            $disableOthers->execute([$data['estado'], $id, $existing['id_logotipo']]);
        } else {
            $saveLogo = $db->prepare(
                'INSERT INTO logotipos
                 (id_institucion, nombre, imagen, categoria, tipo, puntaje, velocidad, probabilidad, estado)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $saveLogo->execute([
                $id, $data['nombre_logotipo'], $logo['imagen'], $logo['categoria'], $logo['tipo'],
                $logo['puntaje'], $logo['velocidad'], $logo['probabilidad'], $data['estado'],
            ]);
        }
        $db->commit();
    } catch (Throwable $error) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        throw $error;
    }
}

function handleRequest(): void
{
    $path = trim((string) ($_GET['path'] ?? ''), '/');
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $body = requestBody();
    $db = database();

    if ($path === 'bootstrap' && $method === 'GET') {
        $institutions = $db->query(
            "SELECT id_institucion, nombre FROM instituciones WHERE estado = 'ACTIVO' ORDER BY nombre"
        )->fetchAll();
        $logos = $db->query(
            "SELECT l.id_logotipo, l.id_institucion, l.nombre, l.imagen, l.categoria,
                    l.tipo, l.puntaje, l.velocidad, l.probabilidad, i.nombre AS institucion
             FROM logotipos l LEFT JOIN instituciones i ON i.id_institucion = l.id_institucion
             WHERE l.estado = 'ACTIVO' ORDER BY l.id_logotipo"
        )->fetchAll();
        $levels = $db->query(
            "SELECT numero_nivel, nombre, puntaje_objetivo, velocidad_caida,
                    frecuencia_logotipos, cantidad_maxima_logotipos
             FROM niveles WHERE estado = 'ACTIVO' ORDER BY numero_nivel"
        )->fetchAll();
        $config = $db->query(
            'SELECT tiempo_partida, sonido_activo FROM configuracion ORDER BY id_configuracion DESC LIMIT 1'
        )->fetch() ?: ['tiempo_partida' => 120, 'sonido_activo' => 1];
        respond(200, compact('institutions', 'logos', 'levels', 'config'));
    }

    if ($path === 'students/register' && $method === 'POST') {
        $first = cleanedString($body, 'nombres', 100);
        $last = cleanedString($body, 'apellidos', 100);
        $username = cleanedString($body, 'nombre_usuario', 50);
        $password = $body['contrasena'] ?? '';
        $institution = filter_var($body['id_institucion'] ?? null, FILTER_VALIDATE_INT);
        if ($first === '' || $last === '' ||
            !preg_match('/^[\p{L}\p{N}_.-]{3,50}$/u', $username) ||
            !is_string($password) || strlen($password) < 8 || strlen($password) > 72 ||
            !$institution || $institution < 1) {
            respond(400, ['error' => 'Completa los datos, usa un usuario válido y una contraseña de 8 a 72 caracteres.']);
        }
        $check = $db->prepare("SELECT id_institucion FROM instituciones WHERE id_institucion = ? AND estado = 'ACTIVO'");
        $check->execute([$institution]);
        if (!$check->fetch()) {
            respond(400, ['error' => 'La institución seleccionada no está disponible. Importa db_juegos.sql en phpMyAdmin.']);
        }
        $db->beginTransaction();
        try {
            $insert = $db->prepare(
                'INSERT INTO usuarios (id_institucion, nombres, apellidos, nombre_usuario, contrasena)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $insert->execute([$institution, $first, $last, $username, password_hash($password, PASSWORD_BCRYPT, ['cost' => 12])]);
            $id = (int) $db->lastInsertId();
            $progress = $db->prepare('INSERT INTO progreso_jugadores (id_usuario) VALUES (?)');
            $progress->execute([$id]);
            $db->commit();
            respond(201, [
                'token' => tokenFor($id, 'student'),
                'player' => [
                    'id' => $id,
                    'username' => $username,
                    'firstName' => $first,
                    'lastName' => $last,
                    'record_personal' => 0,
                    'nivel_maximo' => 1,
                ],
            ]);
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($error instanceof PDOException && $error->getCode() === '23000') {
                respond(409, ['error' => 'Ese nombre de usuario ya está registrado.']);
            }
            throw $error;
        }
    }

    if ($path === 'students/login' && $method === 'POST') {
        $username = cleanedString($body, 'nombre_usuario', 50);
        $password = $body['contrasena'] ?? '';
        if ($username === '' || !is_string($password) || strlen($password) > 72) {
            respond(400, ['error' => 'Ingresa tu nombre de usuario y contraseña.']);
        }
        $query = $db->prepare(
            "SELECT u.id_usuario, u.nombre_usuario, u.nombres, u.apellidos, u.contrasena,
                    COALESCE(p.record_personal, 0) AS record_personal,
                    COALESCE(p.nivel_maximo, 1) AS nivel_maximo
             FROM usuarios u LEFT JOIN progreso_jugadores p ON p.id_usuario = u.id_usuario
             WHERE u.nombre_usuario = ? AND u.estado = 'ACTIVO' LIMIT 1"
        );
        $query->execute([$username]);
        $user = $query->fetch();
        if (!$user || !password_verify($password, $user['contrasena'])) {
            respond(401, ['error' => 'Usuario o contraseña incorrectos.']);
        }
        respond(200, [
            'token' => tokenFor((int) $user['id_usuario'], 'student'),
            'player' => [
                'id' => (int) $user['id_usuario'],
                'username' => $user['nombre_usuario'],
                'firstName' => $user['nombres'],
                'lastName' => $user['apellidos'],
                'record_personal' => (int) $user['record_personal'],
                'nivel_maximo' => (int) $user['nivel_maximo'],
            ],
        ]);
    }

    if ($path === 'students/me' && $method === 'GET') {
        $id = authenticatedId('student');
        $query = $db->prepare(
            "SELECT u.nombre_usuario, u.nombres, u.apellidos, i.nombre AS institucion,
                    COALESCE(p.record_personal, 0) AS record_personal,
                    COALESCE(p.nivel_maximo, 1) AS nivel_maximo
             FROM usuarios u LEFT JOIN instituciones i ON i.id_institucion = u.id_institucion
             LEFT JOIN progreso_jugadores p ON p.id_usuario = u.id_usuario
             WHERE u.id_usuario = ? AND u.estado = 'ACTIVO'"
        );
        $query->execute([$id]);
        $user = $query->fetch();
        if (!$user) {
            respond(404, ['error' => 'No se encontró el jugador.']);
        }
        respond(200, $user);
    }

    if ($path === 'students/history' && $method === 'GET') {
        $query = $db->prepare(
            'SELECT id_partida, puntaje_final, nivel_alcanzado, logotipos_atrapados,
                    logotipos_perdidos, tiempo_jugado, resultado, fecha_inicio
             FROM partidas WHERE id_usuario = ? ORDER BY fecha_inicio DESC LIMIT 30'
        );
        $query->execute([authenticatedId('student')]);
        respond(200, $query->fetchAll());
    }

    if ($path === 'games' && $method === 'POST') {
        $id = authenticatedId('student');
        $score = filter_var($body['puntaje_final'] ?? null, FILTER_VALIDATE_INT);
        $level = filter_var($body['nivel_alcanzado'] ?? null, FILTER_VALIDATE_INT);
        $caught = filter_var($body['logotipos_atrapados'] ?? null, FILTER_VALIDATE_INT);
        $missed = filter_var($body['logotipos_perdidos'] ?? null, FILTER_VALIDATE_INT);
        $duration = filter_var($body['tiempo_jugado'] ?? null, FILTER_VALIDATE_INT);
        $result = in_array($body['resultado'] ?? '', ['VICTORIA', 'DERROTA', 'ABANDONADA'], true)
            ? $body['resultado'] : 'DERROTA';
        if ($score === false || $level === false || $caught === false || $missed === false || $duration === false ||
            $score < -100000 || $score > 1000000 || $level < 1 || $level > 100 ||
            $caught < 0 || $missed < 0 || $duration < 0 || $duration > 86400) {
            respond(400, ['error' => 'Los resultados de la partida no son válidos.']);
        }
        $db->beginTransaction();
        try {
            $game = $db->prepare(
                'INSERT INTO partidas
                 (id_usuario, puntaje_final, nivel_alcanzado, logotipos_atrapados,
                  logotipos_perdidos, tiempo_jugado, resultado, fecha_fin)
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())'
            );
            $game->execute([$id, $score, $level, $caught, $missed, $duration, $result]);
            $progress = $db->prepare(
                'INSERT INTO progreso_jugadores
                 (id_usuario, record_personal, nivel_maximo, total_partidas, total_logotipos)
                 VALUES (?, ?, ?, 1, ?)
                 ON DUPLICATE KEY UPDATE
                   record_personal = GREATEST(record_personal, VALUES(record_personal)),
                   nivel_maximo = GREATEST(nivel_maximo, VALUES(nivel_maximo)),
                   total_partidas = total_partidas + 1,
                   total_logotipos = total_logotipos + VALUES(total_logotipos)'
            );
            $progress->execute([$id, $score, $level, $caught]);
            $db->commit();
            respond(201, ['saved' => true]);
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $error;
        }
    }

    if ($path === 'rankings' && $method === 'GET') {
        $rows = $db->query(
            "SELECT u.nombre_usuario, i.nombre AS institucion,
                    MAX(p.puntaje_final) AS mejor_puntaje,
                    MAX(p.nivel_alcanzado) AS nivel_maximo,
                    COUNT(p.id_partida) AS total_partidas
             FROM usuarios u LEFT JOIN instituciones i ON i.id_institucion = u.id_institucion
             INNER JOIN partidas p ON p.id_usuario = u.id_usuario
             WHERE u.estado = 'ACTIVO'
             GROUP BY u.id_usuario, u.nombre_usuario, i.nombre
             ORDER BY mejor_puntaje DESC, nivel_maximo DESC, total_partidas ASC LIMIT 10"
        )->fetchAll();
        respond(200, $rows);
    }

    if ($path === 'admin/login' && $method === 'POST') {
        enforceLoginRateLimit();
        $username = cleanedString($body, 'usuario', 50);
        $password = $body['contrasena'] ?? '';
        if ($username === '' || !is_string($password) || strlen($password) > 72) {
            respond(400, ['error' => 'Ingresa usuario y contraseña.']);
        }
        $query = $db->prepare(
            "SELECT id_administrador, usuario, contrasena, rol FROM administradores
             WHERE usuario = ? AND estado = 'ACTIVO' LIMIT 1"
        );
        $query->execute([$username]);
        $admin = $query->fetch();
        if (!$admin || !password_verify($password, $admin['contrasena'])) {
            respond(401, ['error' => 'Credenciales administrativas incorrectas.']);
        }
        respond(200, [
            'token' => tokenFor((int) $admin['id_administrador'], 'admin'),
            'admin' => ['usuario' => $admin['usuario'], 'rol' => $admin['rol']],
        ]);
    }

    if ($path === 'admin/institutions' && $method === 'GET') {
        authenticatedId('admin');
        $rows = $db->query(
            'SELECT i.id_institucion, i.nombre, i.codigo, i.estado,
                    l.id_logotipo, l.nombre AS nombre_logotipo, l.imagen, l.categoria,
                    l.tipo, l.puntaje, l.velocidad, l.probabilidad,
                    l.estado AS estado_logotipo
             FROM instituciones i
             LEFT JOIN logotipos l ON l.id_institucion = i.id_institucion
               AND l.id_logotipo = (
                   SELECT MIN(first_logo.id_logotipo)
                   FROM logotipos first_logo
                   WHERE first_logo.id_institucion = i.id_institucion
               )
             ORDER BY i.id_institucion'
        )->fetchAll();
        respond(200, $rows);
    }

    if ($path === 'admin/upload' && $method === 'POST') {
        authenticatedId('admin');
        $file = $_FILES['imagen'] ?? null;
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $uploadError = is_array($file) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
            if ($uploadError === UPLOAD_ERR_INI_SIZE || $uploadError === UPLOAD_ERR_FORM_SIZE) {
                respond(413, ['error' => 'La imagen supera el límite permitido de 3 MB.']);
            }
            respond(400, ['error' => 'Selecciona una imagen PNG, JPG o WEBP.']);
        }
        if (!is_uploaded_file($file['tmp_name']) || (int) $file['size'] < 1 ||
            (int) $file['size'] > 3 * 1024 * 1024) {
            respond(413, ['error' => 'La imagen debe pesar como máximo 3 MB.']);
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        $extensions = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
        if (!is_string($mime) || !isset($extensions[$mime])) {
            respond(415, ['error' => 'Solo se permiten imágenes PNG, JPG o WEBP.']);
        }
        $uploadDirectory = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';
        if (!is_dir($uploadDirectory) &&
            !mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
            respond(500, ['error' => 'No se pudo preparar la carpeta de imágenes.']);
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
        if (!move_uploaded_file($file['tmp_name'], $uploadDirectory . DIRECTORY_SEPARATOR . $filename)) {
            respond(500, ['error' => 'No se pudo guardar la imagen en el servidor.']);
        }
        respond(201, ['imagen' => 'uploads/' . $filename]);
    }

    if ($path === 'admin/institutions' && $method === 'POST') {
        authenticatedId('admin');
        $data = institutionPayload($body);
        if ($data === null) {
            respond(400, ['error' => 'Revisa el nombre, la categoría, el puntaje y la imagen del logotipo.']);
        }
        $db->beginTransaction();
        try {
            $createInstitution = $db->prepare(
                'INSERT INTO instituciones (nombre, codigo) VALUES (?, ?)'
            );
            $createInstitution->execute([$data['nombre'], $data['codigo']]);
            $id = (int) $db->lastInsertId();
            $logo = $data['logo'];
            $createLogo = $db->prepare(
                'INSERT INTO logotipos
                 (id_institucion, nombre, imagen, categoria, tipo, puntaje, velocidad, probabilidad, estado)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $createLogo->execute([
                $id, $data['nombre_logotipo'], $logo['imagen'], $logo['categoria'], $logo['tipo'],
                $logo['puntaje'], $logo['velocidad'], $logo['probabilidad'], $data['estado'],
            ]);
            $db->commit();
            respond(201, ['id_institucion' => $id]);
        } catch (Throwable $error) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            if ($error instanceof PDOException && $error->getCode() === '23000') {
                respond(409, ['error' => 'El código de institución ya existe.']);
            }
            throw $error;
        }
    }

    if (preg_match('~^admin/institutions/([1-9][0-9]*)$~', $path, $matches)) {
        $adminId = authenticatedId('admin');
        $id = (int) $matches[1];
        if ($method === 'PUT') {
            $data = institutionPayload($body);
            if ($data === null) {
                respond(400, ['error' => 'Revisa el nombre, la categoría, el puntaje y la imagen del logotipo.']);
            }
            try {
                updateInstitution($db, $id, $data);
            } catch (PDOException $error) {
                if ($error->getCode() === '23000') {
                    respond(409, ['error' => 'El código de institución ya existe.']);
                }
                throw $error;
            }
            $audit = $db->prepare(
                'INSERT INTO historial_administracion
                 (id_administrador, accion, descripcion, tabla_afectada)
                 VALUES (?, ?, ?, ?)'
            );
            $audit->execute([
                $adminId,
                'EDITAR INSTITUCIÓN',
                'Actualizó el nombre, los datos o el logotipo de la institución ID ' . $id,
                'instituciones/logotipos',
            ]);
            respond(200, ['updated' => true]);
        }
        if ($method === 'DELETE') {
            $db->beginTransaction();
            try {
                $disableInstitution = $db->prepare(
                    "UPDATE instituciones SET estado = 'INACTIVO' WHERE id_institucion = ?"
                );
                $disableInstitution->execute([$id]);
                if ($disableInstitution->rowCount() === 0) {
                    $exists = $db->prepare('SELECT id_institucion FROM instituciones WHERE id_institucion = ?');
                    $exists->execute([$id]);
                    if (!$exists->fetch()) {
                        $db->rollBack();
                        respond(404, ['error' => 'Institución no encontrada.']);
                    }
                }
                $disableLogos = $db->prepare("UPDATE logotipos SET estado = 'INACTIVO' WHERE id_institucion = ?");
                $disableLogos->execute([$id]);
                $db->commit();
                respond(200, ['deactivated' => true]);
            } catch (Throwable $error) {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                throw $error;
            }
        }
    }

    if ($path === 'admin/levels' && $method === 'GET') {
        authenticatedId('admin');
        $levels = $db->query(
            'SELECT numero_nivel, nombre, puntaje_objetivo, velocidad_caida,
                    frecuencia_logotipos, cantidad_maxima_logotipos, dificultad
             FROM niveles ORDER BY numero_nivel'
        )->fetchAll();
        $config = $db->query(
            'SELECT tiempo_partida, velocidad_base, dificultad_general, sonido_activo
             FROM configuracion ORDER BY id_configuracion DESC LIMIT 1'
        )->fetch() ?: [];
        respond(200, compact('levels', 'config'));
    }

    if (preg_match('~^admin/levels/([1-9][0-9]*)$~', $path, $matches) && $method === 'PUT') {
        authenticatedId('admin');
        $number = (int) $matches[1];
        $name = cleanedString($body, 'nombre', 100);
        $goal = filter_var($body['puntaje_objetivo'] ?? null, FILTER_VALIDATE_INT);
        $speed = filter_var($body['velocidad_caida'] ?? null, FILTER_VALIDATE_FLOAT);
        $frequency = filter_var($body['frecuencia_logotipos'] ?? null, FILTER_VALIDATE_INT);
        $maximum = filter_var($body['cantidad_maxima_logotipos'] ?? null, FILTER_VALIDATE_INT);
        if ($number > 100 || $name === '' || $goal === false || $goal < 1 || $goal > 1000000 ||
            $speed === false || $speed < 0.25 || $speed > 10 ||
            $frequency === false || $frequency < 250 || $frequency > 10000 ||
            $maximum === false || $maximum < 1 || $maximum > 50) {
            respond(400, ['error' => 'Los valores del nivel están fuera de rango.']);
        }
        $update = $db->prepare(
            'UPDATE niveles SET nombre = ?, puntaje_objetivo = ?, velocidad_caida = ?,
             frecuencia_logotipos = ?, cantidad_maxima_logotipos = ? WHERE numero_nivel = ?'
        );
        $update->execute([$name, $goal, $speed, $frequency, $maximum, $number]);
        if ($update->rowCount() === 0) {
            $check = $db->prepare('SELECT numero_nivel FROM niveles WHERE numero_nivel = ?');
            $check->execute([$number]);
            if (!$check->fetch()) {
                respond(404, ['error' => 'Nivel no encontrado.']);
            }
        }
        respond(200, ['updated' => true]);
    }

    if ($path === 'admin/settings' && $method === 'PUT') {
        authenticatedId('admin');
        $duration = filter_var($body['tiempo_partida'] ?? null, FILTER_VALIDATE_INT);
        $speed = filter_var($body['velocidad_base'] ?? null, FILTER_VALIDATE_FLOAT);
        $difficulty = $body['dificultad_general'] ?? '';
        if ($duration === false || $duration < 30 || $duration > 600 ||
            $speed === false || $speed < 0.25 || $speed > 5 ||
            !in_array($difficulty, ['FACIL', 'MEDIO', 'DIFICIL'], true)) {
            respond(400, ['error' => 'Configuración general no válida.']);
        }
        $sound = ($body['sonido_activo'] ?? true) === false ? 0 : 1;
        $existing = $db->query(
            'SELECT id_configuracion FROM configuracion ORDER BY id_configuracion DESC LIMIT 1'
        )->fetch();
        if ($existing) {
            $save = $db->prepare(
                'UPDATE configuracion SET tiempo_partida = ?, velocidad_base = ?,
                 dificultad_general = ?, sonido_activo = ? WHERE id_configuracion = ?'
            );
            $save->execute([$duration, $speed, $difficulty, $sound, $existing['id_configuracion']]);
        } else {
            $save = $db->prepare(
                'INSERT INTO configuracion (tiempo_partida, velocidad_base, dificultad_general, sonido_activo)
                 VALUES (?, ?, ?, ?)'
            );
            $save->execute([$duration, $speed, $difficulty, $sound]);
        }
        respond(200, ['updated' => true]);
    }

    if ($path === 'admin/stats' && $method === 'GET') {
        authenticatedId('admin');
        $totals = $db->query(
            "SELECT (SELECT COUNT(*) FROM usuarios WHERE estado = 'ACTIVO') AS jugadores,
                    (SELECT COUNT(*) FROM partidas) AS partidas,
                    (SELECT COUNT(*) FROM instituciones WHERE estado = 'ACTIVO') AS instituciones"
        )->fetch();
        $leaders = $db->query(
            'SELECT u.nombre_usuario, u.nombres, u.apellidos, i.nombre AS institucion,
                    MAX(p.puntaje_final) AS mejor_puntaje,
                    MAX(p.nivel_alcanzado) AS nivel_maximo
             FROM usuarios u LEFT JOIN instituciones i ON i.id_institucion = u.id_institucion
             INNER JOIN partidas p ON p.id_usuario = u.id_usuario
             GROUP BY u.id_usuario, u.nombre_usuario, u.nombres, u.apellidos, i.nombre
             ORDER BY mejor_puntaje DESC LIMIT 10'
        )->fetchAll();
        respond(200, compact('totals', 'leaders'));
    }

    respond(404, ['error' => 'Ruta API no encontrada.']);
}

try {
    handleRequest();
} catch (Throwable $error) {
    error_log('Logo Hunter API: ' . $error->getMessage());
    respond(500, ['error' => 'No se pudo consultar la base de datos. Comprueba MySQL e importa db_juegos.sql.']);
}
