(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const tokenKey = 'logoHunterAdminToken';
  const placeholder = './assets/placeholder.svg';
  const logoAssetVersion = 'levels-transparent-bg-20261104';
  const phpApiUrl = new URL('./api.php', document.currentScript.src).href;
  const usePhpApi = window.location.pathname.includes('/juegos/');
  let token = sessionStorage.getItem(tokenKey) || '';
  let institutions = [];
  let messageTimer;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[char]);
  }

  function logoImageUrl(path) {
    const url = new URL(path || placeholder, window.location.href);
    url.searchParams.set('v', logoAssetVersion);
    return url.href;
  }

  async function api(url, options = {}) {
    const headers = new Headers(options.headers || {});
    if (token) headers.set('Authorization', `Bearer ${token}`);
    if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
    const requestUrl = usePhpApi
      ? `${phpApiUrl}?path=${encodeURIComponent(url.replace(/^\/api\/?/, ''))}`
      : url;
    const response = await fetch(requestUrl, { ...options, headers });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Error del servidor (${response.status}).`);
    return payload;
  }

  function showMessage(message, type = 'success') {
    const node = $('#institution-message');
    node.textContent = message;
    node.className = `institution-message ${type}`;
    clearTimeout(messageTimer);
    if (message) messageTimer = setTimeout(() => {
      node.textContent = '';
      node.className = 'institution-message';
    }, 5000);
  }

  function showManager() {
    $('#institution-login').classList.add('hidden');
    $('#institution-manager').classList.remove('hidden');
    $('#admin-logout').classList.remove('hidden');
  }

  function showLogin(message = '') {
    $('#institution-login').classList.remove('hidden');
    $('#institution-manager').classList.add('hidden');
    $('#admin-logout').classList.add('hidden');
    $('#institution-login-error').textContent = message;
  }

  function categoryScore(category) {
    return ({
      COMUN: 10, ESPECIAL: 25, DORADO: 50, LEGENDARIO: 100,
      CONTAMINADO: -10, PELIGROSO: -25, PENALIZACION: -50
    })[category] || 10;
  }

  function categoryType(category) {
    return ['COMUN', 'ESPECIAL', 'DORADO', 'LEGENDARIO'].includes(category) ? 'POSITIVO' : 'NEGATIVO';
  }

  async function loadInstitutions() {
    const container = $('#institution-list');
    container.setAttribute('aria-busy', 'true');
    container.innerHTML = '<p class="empty-state">Cargando instituciones…</p>';
    try {
      institutions = await api('/api/admin/institutions');
      renderInstitutions();
    } catch (error) {
      if (error.message.includes('sesión expiró') || error.message.includes('Inicia sesión')) {
        token = '';
        sessionStorage.removeItem(tokenKey);
        showLogin('Tu sesión expiró. Ingresa nuevamente como administrador.');
      } else {
        container.innerHTML = `<p class="empty-state">${escapeHtml(error.message)}</p>`;
      }
    } finally {
      container.setAttribute('aria-busy', 'false');
    }
  }

  function renderInstitutions() {
    const container = $('#institution-list');
    if (!institutions.length) {
      container.innerHTML = '<p class="empty-state">Aún no hay instituciones registradas.</p>';
      return;
    }
    container.innerHTML = institutions.map((item) => {
      const active = item.estado === 'ACTIVO';
      return `
        <article class="panel institution-card">
          <img class="institution-emblem" src="${escapeHtml(logoImageUrl(item.imagen))}" alt="Emblema de ${escapeHtml(item.nombre)}">
          <div class="institution-details">
            <span class="status-chip ${active ? '' : 'off'}">● ${active ? 'ACTIVA' : 'INACTIVA'}</span>
            <h2>${escapeHtml(item.nombre)}</h2>
            <p>EN EL JUEGO: ${escapeHtml(item.nombre_logotipo || item.nombre)}</p>
            <div class="institution-meta">
              <span>CÓDIGO: ${escapeHtml(item.codigo || '—')}</span>
              <span>${escapeHtml(item.categoria || '—')} · ${Number(item.puntaje) > 0 ? '+' : ''}${Number(item.puntaje || 0)} PTS</span>
            </div>
          </div>
          <div class="institution-actions">
            <button class="small-button" type="button" data-action="edit" data-id="${Number(item.id_institucion)}">EDITAR</button>
            ${active ? `<button class="small-button institution-delete" type="button" data-action="delete" data-id="${Number(item.id_institucion)}">ELIMINAR</button>` : ''}
          </div>
        </article>`;
    }).join('');
    container.querySelectorAll('.institution-emblem').forEach((image) => {
      image.addEventListener('error', () => {
        image.src = placeholder;
      }, { once: true });
    });
  }

  function openForm(item = null) {
    const form = $('#institution-form');
    form.reset();
    form.classList.remove('hidden');
    $('#institution-form-title').textContent = item ? 'EDITAR INSTITUCIÓN' : 'NUEVA INSTITUCIÓN';
    form.elements.id_institucion.value = item?.id_institucion || '';
    form.elements.nombre.value = item?.nombre || '';
    form.elements.nombre_logotipo.value = item?.nombre_logotipo || item?.nombre || '';
    form.elements.codigo.value = item?.codigo || '';
    form.elements.categoria.value = item?.categoria || 'COMUN';
    form.elements.puntaje.value = item?.puntaje ?? 10;
    form.elements.velocidad.value = item?.velocidad ?? 1;
    form.elements.probabilidad.value = item?.probabilidad ?? 50;
    form.elements.estado.value = item?.estado || 'ACTIVO';
    form.elements.imagen.value = item?.imagen || 'assets/placeholder.svg';
    $('.upload-preview', form).src = logoImageUrl(item?.imagen);
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    form.elements.nombre.focus();
  }

  async function saveInstitution(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const submit = $('button[type="submit"]', form);
    const originalText = submit.textContent;
    submit.disabled = true;
    submit.textContent = 'GUARDANDO…';
    try {
      let image = form.elements.imagen.value || 'assets/placeholder.svg';
      const file = form.elements.archivo.files?.[0];
      if (file) {
        const uploadData = new FormData();
        uploadData.append('imagen', file);
        const uploaded = await api('/api/admin/upload', { method: 'POST', body: uploadData });
        image = uploaded.imagen;
      }
      const category = form.elements.categoria.value;
      const body = {
        nombre: form.elements.nombre.value.trim(),
        nombre_logotipo: form.elements.nombre_logotipo.value.trim(),
        codigo: form.elements.codigo.value.trim(),
        categoria: category,
        tipo: categoryType(category),
        puntaje: Number(form.elements.puntaje.value),
        velocidad: Number(form.elements.velocidad.value),
        probabilidad: Number(form.elements.probabilidad.value),
        imagen: image,
        estado: form.elements.estado.value
      };
      const id = form.elements.id_institucion.value;
      await api(id ? `/api/admin/institutions/${id}` : '/api/admin/institutions', {
        method: id ? 'PUT' : 'POST',
        body: JSON.stringify(body)
      });
      form.classList.add('hidden');
      showMessage(id ? 'Institución actualizada correctamente.' : 'Institución creada correctamente.');
      await loadInstitutions();
    } catch (error) {
      showMessage(error.message, 'error');
    } finally {
      submit.disabled = false;
      submit.textContent = originalText;
    }
  }

  async function deleteInstitution(id) {
    const item = institutions.find((institution) => Number(institution.id_institucion) === id);
    if (!item || !window.confirm(`¿Eliminar "${item.nombre}"? Se desactivará para conservar el historial y podrás reactivarla editándola.`)) return;
    try {
      await api(`/api/admin/institutions/${id}`, { method: 'DELETE' });
      showMessage('Institución desactivada. Su historial se conservó.');
      await loadInstitutions();
    } catch (error) {
      showMessage(error.message, 'error');
    }
  }

  function bindEvents() {
    $('#institution-login-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const errorNode = $('#institution-login-error');
      const submit = $('button[type="submit"]', form);
      errorNode.textContent = '';
      submit.disabled = true;
      submit.textContent = 'VERIFICANDO…';
      try {
        const result = await api('/api/admin/login', {
          method: 'POST',
          body: JSON.stringify(Object.fromEntries(new FormData(form).entries()))
        });
        if (typeof result.token !== 'string' || !result.token) {
          throw new Error('El servidor no devolvió una sesión válida. Inténtalo nuevamente.');
        }
        token = result.token;
        sessionStorage.setItem(tokenKey, token);
        form.reset();
        showManager();
        await loadInstitutions();
      } catch (error) {
        errorNode.textContent = error.message;
      } finally {
        submit.disabled = false;
        submit.innerHTML = 'INGRESAR COMO ADMIN <span>→</span>';
      }
    });
    $('#admin-logout').addEventListener('click', () => {
      token = '';
      sessionStorage.removeItem(tokenKey);
      institutions = [];
      $('#institution-form').classList.add('hidden');
      showLogin();
    });
    $('#new-institution').addEventListener('click', () => openForm());
    $('#cancel-institution').addEventListener('click', () => $('#institution-form').classList.add('hidden'));
    $('#close-institution-form').addEventListener('click', () => $('#institution-form').classList.add('hidden'));
    $('#institution-form').addEventListener('submit', saveInstitution);
    $('#institution-form [name="categoria"]').addEventListener('change', (event) => {
      $('#institution-form [name="puntaje"]').value = String(categoryScore(event.target.value));
    });
    $('#institution-form [name="archivo"]').addEventListener('change', (event) => {
      const file = event.target.files?.[0];
      if (!file) return;
      if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 3 * 1024 * 1024) {
        event.target.value = '';
        showMessage('Elige un archivo PNG, JPG o WEBP de hasta 3 MB.', 'error');
        return;
      }
      $('.upload-preview', event.target.form).src = URL.createObjectURL(file);
    });
    $('#institution-list').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-action]');
      if (!button) return;
      const id = Number(button.dataset.id);
      if (button.dataset.action === 'edit') {
        const item = institutions.find((institution) => Number(institution.id_institucion) === id);
        if (item) openForm(item);
      } else if (button.dataset.action === 'delete') {
        deleteInstitution(id);
      }
    });
  }

  bindEvents();
  if (token) {
    showManager();
    loadInstitutions();
  } else {
    showLogin();
  }
})();
