require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('../src/db');

async function createAdmin() {
  const username = process.env.ADMIN_USER;
  const password = process.env.ADMIN_PASSWORD;
  if (!username || !password || password.length < 12) {
    throw new Error('Define ADMIN_USER y ADMIN_PASSWORD (mínimo 12 caracteres) en .env.');
  }
  const hash = await bcrypt.hash(password, 12);
  await pool.execute(
    `INSERT INTO administradores (nombres, apellidos, usuario, contrasena, rol)
     VALUES (?, ?, ?, ?, 'SUPERADMIN')`,
    ['Administrador', 'Principal', username, hash]
  );
  console.log(`Administrador "${username}" creado.`);
}

createAdmin()
  .catch((error) => {
    console.error('No se pudo crear el administrador:', error.code === 'ER_DUP_ENTRY' ? 'el usuario ya existe.' : error.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
