<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

function setting(string $key, string $fallback = ''): string
{
    $value = getenv($key);
    if ($value !== false) {
        return $value;
    }

    static $settings = null;
    if ($settings === null) {
        $settings = [];
        $envFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';
        foreach (is_file($envFile) ? file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [] as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                continue;
            }
            [$name, $value] = explode('=', $line, 2);
            $settings[trim($name)] = trim(trim($value), "\"'");
        }
    }

    return $settings[$key] ?? $fallback;
}

$username = setting('ADMIN_USER');
$password = setting('ADMIN_PASSWORD');
if ($username === '' || strlen($username) > 50 || strlen($password) < 12 || strlen($password) > 72) {
    fwrite(STDERR, "Define ADMIN_USER y ADMIN_PASSWORD (12 a 72 caracteres) en .env.\n");
    exit(1);
}

try {
    $pdo = new PDO(
        'mysql:host=' . setting('DB_HOST', '127.0.0.1') .
            ';port=' . setting('DB_PORT', '3306') .
            ';dbname=' . setting('DB_NAME', 'logo_hunter_db') . ';charset=utf8mb4',
        setting('DB_USER', 'root'),
        setting('DB_PASSWORD'),
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $insert = $pdo->prepare(
        "INSERT INTO administradores (nombres, apellidos, usuario, contrasena, rol)
         VALUES (?, ?, ?, ?, 'SUPERADMIN')"
    );
    $insert->execute([
        'Administrador',
        'Principal',
        $username,
        password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
    ]);
    fwrite(STDOUT, "Administrador creado. Ya puedes retirar ADMIN_USER y ADMIN_PASSWORD de .env.\n");
} catch (PDOException $error) {
    if ($error->getCode() === '23000') {
        fwrite(STDERR, "Ese usuario administrador ya existe.\n");
        exit(1);
    }
    fwrite(STDERR, "No se pudo crear el administrador: {$error->getMessage()}\n");
    exit(1);
}
