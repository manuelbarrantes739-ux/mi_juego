const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  database: process.env.DB_NAME || 'logo_hunter_db',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4'
});

async function initializeDatabase() {
  await pool.query('SELECT 1');
  if (!process.env.ADMIN_USER || !process.env.ADMIN_PASSWORD) return;
  if (process.env.ADMIN_PASSWORD.length < 12) {
    throw new Error('ADMIN_PASSWORD debe tener al menos 12 caracteres.');
  }
  const [existing] = await pool.execute(
    'SELECT id_administrador FROM administradores WHERE usuario = ? LIMIT 1',
    [process.env.ADMIN_USER]
  );
  if (existing.length) return;
  const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
  await pool.execute(
    `INSERT INTO administradores (nombres, apellidos, usuario, contrasena, rol)
     VALUES (?, ?, ?, ?, 'SUPERADMIN')`,
    ['Administrador', 'Principal', process.env.ADMIN_USER, hash]
  );
  console.log('Cuenta administrativa inicial creada desde variables de entorno.');
}

module.exports = { pool, initializeDatabase };
