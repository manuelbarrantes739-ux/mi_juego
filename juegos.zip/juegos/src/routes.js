const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const rateLimit = require('express-rate-limit');
const { pool } = require('./db');
const { createToken, authenticate } = require('./auth');

const router = express.Router();
const studentAuth = authenticate('student');
const adminAuth = authenticate('admin');
const loginLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Demasiados intentos. Espera unos minutos.' }
});
const uploadDirectory = path.join(__dirname, '..', 'public', 'uploads');
fs.mkdirSync(uploadDirectory, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDirectory,
    filename: (req, file, done) => {
      const extensions = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp' };
      done(null, `${crypto.randomBytes(16).toString('hex')}${extensions[file.mimetype] || ''}`);
    }
  }),
  limits: { fileSize: 3 * 1024 * 1024 },
  fileFilter: (req, file, done) => {
    if (!new Set(['image/png', 'image/jpeg', 'image/webp']).has(file.mimetype)) {
      return done(new Error('Formato de imagen no permitido.'));
    }
    return done(null, true);
  }
});
const categories = new Set([
  'COMUN', 'ESPECIAL', 'DORADO', 'LEGENDARIO',
  'CONTAMINADO', 'PELIGROSO', 'PENALIZACION'
]);
const positive = new Set(['COMUN', 'ESPECIAL', 'DORADO', 'LEGENDARIO']);
const clean = (value, limit = 100) => typeof value === 'string' ? value.trim().slice(0, limit) : '';
const errorResponse = (res, status, error) => res.status(status).json({ error });

router.get('/bootstrap', async (req, res, next) => {
  try {
    const [institutionRows, logoRows, levelRows, configRows] = await Promise.all([
      pool.query(`SELECT id_institucion, nombre FROM instituciones
                  WHERE estado = 'ACTIVO' ORDER BY nombre`),
      pool.query(`SELECT l.id_logotipo, l.id_institucion, l.nombre, l.imagen,
                         l.categoria, l.tipo, l.puntaje, l.velocidad, l.probabilidad,
                         i.nombre AS institucion
                  FROM logotipos l LEFT JOIN instituciones i
                    ON i.id_institucion = l.id_institucion
                  WHERE l.estado = 'ACTIVO' ORDER BY l.id_logotipo`),
      pool.query(`SELECT numero_nivel, nombre, puntaje_objetivo, velocidad_caida,
                         frecuencia_logotipos, cantidad_maxima_logotipos
                  FROM niveles WHERE estado = 'ACTIVO' ORDER BY numero_nivel`),
      pool.query(`SELECT tiempo_partida, sonido_activo FROM configuracion
                  ORDER BY id_configuracion DESC LIMIT 1`)
    ]);
    res.json({
      institutions: institutionRows[0],
      logos: logoRows[0],
      levels: levelRows[0],
      config: configRows[0][0] || { tiempo_partida: 120, sonido_activo: 1 }
    });
  } catch (error) {
    next(error);
  }
});

router.post('/students/register', loginLimit, async (req, res, next) => {
  const firstName = clean(req.body.nombres, 100);
  const lastName = clean(req.body.apellidos, 100);
  const username = clean(req.body.nombre_usuario, 50);
  const password = typeof req.body.contrasena === 'string' ? req.body.contrasena : '';
  const institutionId = Number(req.body.id_institucion);
  if (!firstName || !lastName || !/^[\p{L}\p{N}_.-]{3,50}$/u.test(username) ||
      password.length < 8 || Buffer.byteLength(password, 'utf8') > 72 ||
      !Number.isInteger(institutionId) || institutionId < 1) {
    return errorResponse(res, 400, 'Completa los datos, usa un usuario válido y una contraseña de 8 a 72 caracteres.');
  }
  try {
    const [institution] = await pool.execute(
      `SELECT id_institucion FROM instituciones
       WHERE id_institucion = ? AND estado = 'ACTIVO'`,
      [institutionId]
    );
    if (!institution.length) return errorResponse(res, 400, 'La institución seleccionada no está disponible.');
    const passwordHash = await bcrypt.hash(password, 12);
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      const [created] = await connection.execute(
        `INSERT INTO usuarios (id_institucion, nombres, apellidos, nombre_usuario, contrasena)
         VALUES (?, ?, ?, ?, ?)`,
        [institutionId, firstName, lastName, username, passwordHash]
      );
      await connection.execute('INSERT INTO progreso_jugadores (id_usuario) VALUES (?)', [created.insertId]);
      await connection.commit();
      res.status(201).json({
        token: createToken(created.insertId, 'student'),
        player: {
          id: created.insertId, username, firstName, lastName,
          record_personal: 0, nivel_maximo: 1
        }
      });
    } catch (error) {
      await connection.rollback();
      if (error.code === 'ER_DUP_ENTRY') return errorResponse(res, 409, 'Ese nombre de usuario ya está registrado.');
      throw error;
    } finally {
      connection.release();
    }
  } catch (error) {
    next(error);
  }
});

router.post('/students/login', loginLimit, async (req, res, next) => {
  const username = clean(req.body.nombre_usuario, 50);
  const password = typeof req.body.contrasena === 'string' ? req.body.contrasena : '';
  if (!username || !password || password.length > 72) {
    return errorResponse(res, 400, 'Ingresa tu nombre de usuario y contraseña.');
  }
  try {
    const [rows] = await pool.execute(
      `SELECT u.id_usuario, u.nombre_usuario, u.nombres, u.apellidos, u.contrasena,
              COALESCE(pr.record_personal, 0) AS record_personal,
              COALESCE(pr.nivel_maximo, 1) AS nivel_maximo
       FROM usuarios u
       LEFT JOIN progreso_jugadores pr ON pr.id_usuario = u.id_usuario
       WHERE u.nombre_usuario = ? AND u.estado = 'ACTIVO' LIMIT 1`,
      [username]
    );
    if (!rows.length || !(await bcrypt.compare(password, rows[0].contrasena))) {
      return errorResponse(res, 401, 'Usuario o contraseña incorrectos.');
    }
    res.json({
      token: createToken(rows[0].id_usuario, 'student'),
      player: {
        id: rows[0].id_usuario,
        username: rows[0].nombre_usuario,
        firstName: rows[0].nombres,
        lastName: rows[0].apellidos,
        record_personal: rows[0].record_personal,
        nivel_maximo: rows[0].nivel_maximo
      }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/students/me', studentAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT u.nombre_usuario, u.nombres, u.apellidos, i.nombre AS institucion,
              pr.record_personal, pr.nivel_maximo
       FROM usuarios u
       LEFT JOIN instituciones i ON i.id_institucion = u.id_institucion
       LEFT JOIN progreso_jugadores pr ON pr.id_usuario = u.id_usuario
       WHERE u.id_usuario = ? AND u.estado = 'ACTIVO'`,
      [req.auth.id]
    );
    if (!rows.length) return errorResponse(res, 404, 'No se encontró el jugador.');
    res.json(rows[0]);
  } catch (error) {
    next(error);
  }
});

router.get('/students/history', studentAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT id_partida, puntaje_final, nivel_alcanzado, logotipos_atrapados,
              logotipos_perdidos, tiempo_jugado, resultado, fecha_inicio
       FROM partidas WHERE id_usuario = ? ORDER BY fecha_inicio DESC LIMIT 30`,
      [req.auth.id]
    );
    res.json(rows);
  } catch (error) {
    next(error);
  }
});

router.post('/games', studentAuth, async (req, res, next) => {
  const score = Number(req.body.puntaje_final);
  const level = Number(req.body.nivel_alcanzado);
  const caught = Number(req.body.logotipos_atrapados);
  const missed = Number(req.body.logotipos_perdidos);
  const duration = Number(req.body.tiempo_jugado);
  const result = ['VICTORIA', 'DERROTA', 'ABANDONADA'].includes(req.body.resultado)
    ? req.body.resultado : 'DERROTA';
  if (![score, level, caught, missed, duration].every(Number.isFinite) ||
      ![score, level, caught, missed, duration].every(Number.isInteger) ||
      score < -100000 || score > 1000000 || level < 1 || level > 100 ||
      caught < 0 || missed < 0 || duration < 0 || duration > 86400) {
    return errorResponse(res, 400, 'Los resultados de la partida no son válidos.');
  }
  let connection;
  try {
    connection = await pool.getConnection();
    await connection.beginTransaction();
    await connection.execute(
      `INSERT INTO partidas
       (id_usuario, puntaje_final, nivel_alcanzado, logotipos_atrapados,
        logotipos_perdidos, tiempo_jugado, resultado, fecha_fin)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [req.auth.id, score, level, caught, missed, duration, result]
    );
    await connection.execute(
      `INSERT INTO progreso_jugadores
       (id_usuario, record_personal, nivel_maximo, total_partidas, total_logotipos)
       VALUES (?, ?, ?, 1, ?)
       ON DUPLICATE KEY UPDATE
         record_personal = GREATEST(record_personal, VALUES(record_personal)),
         nivel_maximo = GREATEST(nivel_maximo, VALUES(nivel_maximo)),
         total_partidas = total_partidas + 1,
         total_logotipos = total_logotipos + VALUES(total_logotipos)`,
      [req.auth.id, score, level, caught]
    );
    await connection.commit();
    res.status(201).json({ saved: true });
  } catch (error) {
    if (connection) await connection.rollback();
    next(error);
  } finally {
    if (connection) connection.release();
  }
});

router.get('/rankings', async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT u.nombre_usuario, u.nombres, u.apellidos, i.nombre AS institucion,
              MAX(p.puntaje_final) AS mejor_puntaje,
              MAX(p.nivel_alcanzado) AS nivel_maximo,
              COUNT(p.id_partida) AS total_partidas
       FROM usuarios u LEFT JOIN instituciones i ON i.id_institucion = u.id_institucion
       INNER JOIN partidas p ON p.id_usuario = u.id_usuario
       WHERE u.estado = 'ACTIVO'
       GROUP BY u.id_usuario, u.nombre_usuario, u.nombres, u.apellidos, i.nombre
       ORDER BY mejor_puntaje DESC, nivel_maximo DESC, total_partidas ASC LIMIT 10`
    );
    res.json(rows);
  } catch (error) {
    next(error);
  }
});

router.post('/admin/login', loginLimit, async (req, res, next) => {
  const username = clean(req.body.usuario, 50);
  const password = typeof req.body.contrasena === 'string' ? req.body.contrasena : '';
  if (!username || !password) return errorResponse(res, 400, 'Ingresa usuario y contraseña.');
  try {
    const [rows] = await pool.execute(
      `SELECT id_administrador, usuario, contrasena, rol FROM administradores
       WHERE usuario = ? AND estado = 'ACTIVO' LIMIT 1`,
      [username]
    );
    if (!rows.length || !(await bcrypt.compare(password, rows[0].contrasena))) {
      return errorResponse(res, 401, 'Credenciales administrativas incorrectas.');
    }
    res.json({
      token: createToken(rows[0].id_administrador, 'admin'),
      admin: { usuario: rows[0].usuario, rol: rows[0].rol }
    });
  } catch (error) {
    next(error);
  }
});

router.get('/admin/institutions', adminAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT i.id_institucion, i.nombre, i.codigo, i.estado,
              l.id_logotipo, l.nombre AS nombre_logotipo, l.imagen, l.categoria, l.tipo, l.puntaje,
              l.velocidad, l.probabilidad, l.estado AS estado_logotipo
       FROM instituciones i
       LEFT JOIN logotipos l ON l.id_institucion = i.id_institucion
       ORDER BY i.id_institucion`
    );
    res.json(rows);
  } catch (error) {
    next(error);
  }
});

router.post('/admin/upload', adminAuth, upload.single('imagen'), (req, res) => {
  if (!req.file) return errorResponse(res, 400, 'Selecciona una imagen PNG, JPG o WEBP.');
  fs.promises.readFile(req.file.path).then((content) => {
    const png = req.file.mimetype === 'image/png' &&
      content.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
    const jpeg = req.file.mimetype === 'image/jpeg' &&
      content[0] === 255 && content[1] === 216 && content[2] === 255;
    const webp = req.file.mimetype === 'image/webp' &&
      content.toString('ascii', 0, 4) === 'RIFF' && content.toString('ascii', 8, 12) === 'WEBP';
    if (!png && !jpeg && !webp) {
      return fs.promises.unlink(req.file.path)
        .then(() => errorResponse(res, 415, 'El contenido no coincide con una imagen PNG, JPG o WEBP.'));
    }
    return res.status(201).json({ imagen: `uploads/${req.file.filename}` });
  }).catch((error) => {
    next(error);
  });
});

function validLogo(body) {
  const category = clean(body.categoria, 20).toUpperCase();
  const type = clean(body.tipo, 20).toUpperCase();
  const score = Number(body.puntaje);
  const image = clean(body.imagen, 255);
  const isPositive = new Set(['COMUN', 'ESPECIAL', 'DORADO', 'LEGENDARIO']).has(category);
  if (!categories.has(category) || !Number.isInteger(score) ||
      Math.abs(score) > 10000 || type !== (isPositive ? 'POSITIVO' : 'NEGATIVO') ||
      !/^(?:assets\/placeholder\.svg|uploads\/(?:[a-f0-9]{32}\.(?:png|jpg|webp)|(?:comercio32|encinas|ina91|jose-maria-arguedas|mercedes|peru-birf|politecnico|vilcapaza)\.png))$/i.test(image)) return null;
  return {
    category, type, score,
    speed: Math.min(5, Math.max(0.25, Number(body.velocidad) || 1)),
    probability: Math.min(100, Math.max(1, Math.round(Number(body.probabilidad) || 50))),
    image
  };
}

router.post('/admin/institutions', adminAuth, async (req, res, next) => {
  const name = clean(req.body.nombre, 150);
  const logoName = clean(req.body.nombre_logotipo, 150) || name;
  const code = clean(req.body.codigo, 30) || null;
  const logo = validLogo(req.body);
  if (!name || !logo) return errorResponse(res, 400, 'Revisa el nombre y los datos del logotipo.');
  let connection;
  try {
    connection = await pool.getConnection();
    await connection.beginTransaction();
    const [created] = await connection.execute(
      'INSERT INTO instituciones (nombre, codigo) VALUES (?, ?)', [name, code]
    );
    await connection.execute(
      `INSERT INTO logotipos
       (id_institucion, nombre, imagen, categoria, tipo, puntaje, velocidad, probabilidad)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [created.insertId, logoName, logo.image, logo.category, logo.type, logo.score, logo.speed, logo.probability]
    );
    await connection.commit();
    res.status(201).json({ id_institucion: created.insertId });
  } catch (error) {
    if (connection) await connection.rollback();
    if (error.code === 'ER_DUP_ENTRY') return errorResponse(res, 409, 'El código de institución ya existe.');
    next(error);
  } finally {
    if (connection) connection.release();
  }
});

router.put('/admin/institutions/:id', adminAuth, async (req, res, next) => {
  const id = Number(req.params.id);
  const name = clean(req.body.nombre, 150);
  const logoName = clean(req.body.nombre_logotipo, 150) || name;
  const code = clean(req.body.codigo, 30) || null;
  const state = req.body.estado === 'INACTIVO' ? 'INACTIVO' : 'ACTIVO';
  const logo = validLogo(req.body);
  if (!Number.isInteger(id) || id < 1 || !name || !logo) {
    return errorResponse(res, 400, 'Revisa los datos de la institución.');
  }
  let connection;
  try {
    connection = await pool.getConnection();
    await connection.beginTransaction();
    const [updated] = await connection.execute(
      'UPDATE instituciones SET nombre = ?, codigo = ?, estado = ? WHERE id_institucion = ?',
      [name, code, state, id]
    );
    if (!updated.affectedRows) {
      await connection.rollback();
      return errorResponse(res, 404, 'Institución no encontrada.');
    }
    const [existing] = await connection.execute(
      'SELECT id_logotipo FROM logotipos WHERE id_institucion = ? ORDER BY id_logotipo LIMIT 1',
      [id]
    );
    if (existing.length) {
      await connection.execute(
        `UPDATE logotipos SET nombre = ?, imagen = ?, categoria = ?, tipo = ?,
         puntaje = ?, velocidad = ?, probabilidad = ?, estado = ? WHERE id_logotipo = ?`,
        [logoName, logo.image, logo.category, logo.type, logo.score, logo.speed,
          logo.probability, state, existing[0].id_logotipo]
      );
      await connection.execute(
        'UPDATE logotipos SET estado = ? WHERE id_institucion = ? AND id_logotipo <> ?',
        [state, id, existing[0].id_logotipo]
      );
    } else {
      await connection.execute(
        `INSERT INTO logotipos
         (id_institucion, nombre, imagen, categoria, tipo, puntaje, velocidad, probabilidad, estado)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, logoName, logo.image, logo.category, logo.type, logo.score,
          logo.speed, logo.probability, state]
      );
    }
    await connection.commit();
    res.json({ updated: true });
  } catch (error) {
    if (connection) await connection.rollback();
    if (error.code === 'ER_DUP_ENTRY') return errorResponse(res, 409, 'El código de institución ya existe.');
    next(error);
  } finally {
    if (connection) connection.release();
  }
});

router.delete('/admin/institutions/:id', adminAuth, async (req, res, next) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return errorResponse(res, 400, 'Identificador no válido.');
  try {
    const [updated] = await pool.execute(
      `UPDATE instituciones SET estado = 'INACTIVO' WHERE id_institucion = ?`, [id]
    );
    if (!updated.affectedRows) return errorResponse(res, 404, 'Institución no encontrada.');
    await pool.execute(`UPDATE logotipos SET estado = 'INACTIVO' WHERE id_institucion = ?`, [id]);
    res.json({ deactivated: true });
  } catch (error) {
    next(error);
  }
});

router.get('/admin/levels', adminAuth, async (req, res, next) => {
  try {
    const [levels] = await pool.query(
      `SELECT numero_nivel, nombre, puntaje_objetivo, velocidad_caida,
              frecuencia_logotipos, cantidad_maxima_logotipos, dificultad
       FROM niveles ORDER BY numero_nivel`
    );
    const [config] = await pool.query(
      `SELECT tiempo_partida, velocidad_base, dificultad_general, sonido_activo
       FROM configuracion ORDER BY id_configuracion DESC LIMIT 1`
    );
    res.json({ levels, config: config[0] || {} });
  } catch (error) {
    next(error);
  }
});

router.put('/admin/levels/:number', adminAuth, async (req, res, next) => {
  const number = Number(req.params.number);
  const goal = Number(req.body.puntaje_objetivo);
  const speed = Number(req.body.velocidad_caida);
  const frequency = Number(req.body.frecuencia_logotipos);
  const maxLogos = Number(req.body.cantidad_maxima_logotipos);
  const name = clean(req.body.nombre, 100);
  if (!Number.isInteger(number) || number < 1 || number > 100 || !name ||
      !Number.isInteger(goal) || goal < 1 || goal > 1000000 ||
      !Number.isFinite(speed) || speed < 0.25 || speed > 10 ||
      !Number.isInteger(frequency) || frequency < 250 || frequency > 10000 ||
      !Number.isInteger(maxLogos) || maxLogos < 1 || maxLogos > 50) {
    return errorResponse(res, 400, 'Los valores del nivel están fuera de rango.');
  }
  try {
    const [updated] = await pool.execute(
      `UPDATE niveles SET nombre = ?, puntaje_objetivo = ?, velocidad_caida = ?,
       frecuencia_logotipos = ?, cantidad_maxima_logotipos = ? WHERE numero_nivel = ?`,
      [name, goal, speed, frequency, maxLogos, number]
    );
    if (!updated.affectedRows) return errorResponse(res, 404, 'Nivel no encontrado.');
    res.json({ updated: true });
  } catch (error) {
    next(error);
  }
});

router.put('/admin/settings', adminAuth, async (req, res, next) => {
  const duration = Number(req.body.tiempo_partida);
  const speed = Number(req.body.velocidad_base);
  const difficulty = ['FACIL', 'MEDIO', 'DIFICIL'].includes(req.body.dificultad_general)
    ? req.body.dificultad_general : null;
  if (!Number.isInteger(duration) || duration < 30 || duration > 600 ||
      !Number.isFinite(speed) || speed < 0.25 || speed > 5 || !difficulty) {
    return errorResponse(res, 400, 'Configuración general no válida.');
  }
  try {
    const [rows] = await pool.query(
      'SELECT id_configuracion FROM configuracion ORDER BY id_configuracion DESC LIMIT 1'
    );
    const values = [duration, speed, difficulty, req.body.sonido_activo === false ? 0 : 1];
    if (rows.length) {
      await pool.execute(
        `UPDATE configuracion SET tiempo_partida = ?, velocidad_base = ?,
         dificultad_general = ?, sonido_activo = ? WHERE id_configuracion = ?`,
        [...values, rows[0].id_configuracion]
      );
    } else {
      await pool.execute(
        `INSERT INTO configuracion (tiempo_partida, velocidad_base, dificultad_general, sonido_activo)
         VALUES (?, ?, ?, ?)`, values
      );
    }
    res.json({ updated: true });
  } catch (error) {
    next(error);
  }
});

router.get('/admin/stats', adminAuth, async (req, res, next) => {
  try {
    const [[totals]] = await pool.query(
      `SELECT (SELECT COUNT(*) FROM usuarios WHERE estado = 'ACTIVO') AS jugadores,
              (SELECT COUNT(*) FROM partidas) AS partidas,
              (SELECT COUNT(*) FROM instituciones WHERE estado = 'ACTIVO') AS instituciones`
    );
    const [leaders] = await pool.query(
      `SELECT u.nombre_usuario, u.nombres, u.apellidos, i.nombre AS institucion,
              MAX(p.puntaje_final) AS mejor_puntaje, MAX(p.nivel_alcanzado) AS nivel_maximo
       FROM usuarios u LEFT JOIN instituciones i ON i.id_institucion = u.id_institucion
       INNER JOIN partidas p ON p.id_usuario = u.id_usuario
       GROUP BY u.id_usuario, u.nombre_usuario, u.nombres, u.apellidos, i.nombre
       ORDER BY mejor_puntaje DESC LIMIT 10`
    );
    res.json({ totals, leaders });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
