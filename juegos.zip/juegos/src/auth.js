const jwt = require('jsonwebtoken');

function createToken(id, role) {
  return jwt.sign({ sub: String(id), role }, process.env.JWT_SECRET, { expiresIn: '12h' });
}

function authenticate(role) {
  return (req, res, next) => {
    const header = req.get('authorization') || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) return res.status(401).json({ error: 'Inicia sesión para continuar.' });
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      if (payload.role !== role || !/^\d+$/.test(payload.sub)) {
        return res.status(403).json({ error: 'No tienes permiso para esta acción.' });
      }
      req.auth = { id: Number(payload.sub), role: payload.role };
      return next();
    } catch (error) {
      return res.status(401).json({ error: 'La sesión expiró. Inicia sesión nuevamente.' });
    }
  };
}

module.exports = { createToken, authenticate };
