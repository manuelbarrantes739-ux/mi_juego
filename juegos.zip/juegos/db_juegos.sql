
-- ==========================================
-- PROYECTO: LOGO HUNTER - TERMINATOR EDITION
-- BASE DE DATOS: logo_hunter_db
-- MOTOR: MySQL
-- ==========================================

CREATE DATABASE IF NOT EXISTS logo_hunter_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE logo_hunter_db;

-- ==========================================
-- 1. TABLA: ADMINISTRADORES
-- ==========================================

CREATE TABLE administradores (
    id_administrador INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    rol ENUM('SUPERADMIN','ADMIN') DEFAULT 'ADMIN',
    estado ENUM('ACTIVO','INACTIVO') DEFAULT 'ACTIVO',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 2. TABLA: INSTITUCIONES EDUCATIVAS
-- ==========================================

CREATE TABLE instituciones (
    id_institucion INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    codigo VARCHAR(30) UNIQUE,
    descripcion TEXT,
    logotipo VARCHAR(255),
    ubicacion VARCHAR(150),
    estado ENUM('ACTIVO','INACTIVO') DEFAULT 'ACTIVO',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 3. TABLA: USUARIOS / ESTUDIANTES
-- ==========================================

CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    id_institucion INT,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    nombre_usuario VARCHAR(50) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    correo VARCHAR(150),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('ACTIVO','INACTIVO') DEFAULT 'ACTIVO',

    FOREIGN KEY (id_institucion)
    REFERENCES instituciones(id_institucion)
    ON DELETE SET NULL
    ON UPDATE CASCADE
);

-- ==========================================
-- 4. TABLA: LOGOTIPOS DEL JUEGO
-- ==========================================

CREATE TABLE logotipos (
    id_logotipo INT AUTO_INCREMENT PRIMARY KEY,
    id_institucion INT,
    nombre VARCHAR(150) NOT NULL,
    imagen VARCHAR(255) NOT NULL,
    categoria ENUM(
        'COMUN',
        'ESPECIAL',
        'DORADO',
        'LEGENDARIO',
        'CONTAMINADO',
        'PELIGROSO',
        'PENALIZACION'
    ) NOT NULL,
    tipo ENUM('POSITIVO','NEGATIVO') NOT NULL,
    puntaje INT NOT NULL,
    velocidad DECIMAL(5,2) DEFAULT 1.00,
    probabilidad INT DEFAULT 50,
    estado ENUM('ACTIVO','INACTIVO') DEFAULT 'ACTIVO',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_institucion)
    REFERENCES instituciones(id_institucion)
    ON DELETE SET NULL
    ON UPDATE CASCADE
);

-- ==========================================
-- 5. TABLA: NIVELES
-- ==========================================

CREATE TABLE niveles (
    id_nivel INT AUTO_INCREMENT PRIMARY KEY,
    numero_nivel INT NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    puntaje_objetivo INT NOT NULL,
    velocidad_caida DECIMAL(5,2) DEFAULT 1.00,
    frecuencia_logotipos INT DEFAULT 1000,
    cantidad_maxima_logotipos INT DEFAULT 5,
    dificultad ENUM('FACIL','MEDIO','DIFICIL','EXTREMO')
    DEFAULT 'FACIL',
    estado ENUM('ACTIVO','INACTIVO') DEFAULT 'ACTIVO'
);

-- ==========================================
-- 6. TABLA: PARTIDAS
-- ==========================================

CREATE TABLE partidas (
    id_partida INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    puntaje_final INT DEFAULT 0,
    nivel_alcanzado INT DEFAULT 1,
    logotipos_atrapados INT DEFAULT 0,
    logotipos_perdidos INT DEFAULT 0,
    tiempo_jugado INT DEFAULT 0,
    resultado ENUM('VICTORIA','DERROTA','ABANDONADA')
    DEFAULT 'DERROTA',
    fecha_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_fin DATETIME NULL,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

-- ==========================================
-- 7. TABLA: DETALLE DE PARTIDAS
-- ==========================================

CREATE TABLE detalle_partidas (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_partida INT NOT NULL,
    id_logotipo INT NOT NULL,
    cantidad INT DEFAULT 1,
    puntaje_obtenido INT NOT NULL,
    fecha_captura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_partida)
    REFERENCES partidas(id_partida)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

    FOREIGN KEY (id_logotipo)
    REFERENCES logotipos(id_logotipo)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

-- ==========================================
-- 8. TABLA: PROGRESO DE JUGADORES
-- ==========================================

CREATE TABLE progreso_jugadores (
    id_progreso INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL UNIQUE,
    record_personal INT DEFAULT 0,
    nivel_maximo INT DEFAULT 1,
    total_partidas INT DEFAULT 0,
    total_logotipos INT DEFAULT 0,
    fecha_actualizacion TIMESTAMP
    DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

-- ==========================================
-- 9. TABLA: CONFIGURACION DEL JUEGO
-- ==========================================

CREATE TABLE configuracion (
    id_configuracion INT AUTO_INCREMENT PRIMARY KEY,
    nombre_juego VARCHAR(100) DEFAULT 'LOGO HUNTER',
    tiempo_partida INT DEFAULT 120,
    velocidad_base DECIMAL(5,2) DEFAULT 1.00,
    dificultad_general ENUM('FACIL','MEDIO','DIFICIL')
    DEFAULT 'MEDIO',
    sonido_activo BOOLEAN DEFAULT TRUE,
    pantalla_completa BOOLEAN DEFAULT TRUE,
    puntos_iniciales INT DEFAULT 0,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP
);

-- ==========================================
-- 10. TABLA: HISTORIAL DE ADMINISTRACION
-- ==========================================

CREATE TABLE historial_administracion (
    id_historial INT AUTO_INCREMENT PRIMARY KEY,
    id_administrador INT,
    accion VARCHAR(100) NOT NULL,
    descripcion TEXT,
    tabla_afectada VARCHAR(100),
    fecha_accion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_administrador)
    REFERENCES administradores(id_administrador)
    ON DELETE SET NULL
    ON UPDATE CASCADE
);

-- ==========================================
-- 11. REGISTRO DE INSTITUCIONES INICIALES
-- ==========================================

INSERT INTO instituciones (nombre, codigo, ubicacion)
VALUES
('Perú Birf', 'IE001', 'Juliaca'),
('Politécnico', 'IE002', 'Juliaca'),
('José Antonio Encinas', 'IE003', 'Juliaca'),
('Las Mercedes', 'IE004', 'Juliaca'),
('Comercio 32', 'IE005', 'Juliaca'),
('INA 91', 'IE006', 'Juliaca'),
('José María Arguedas', 'IE007', 'Juliaca'),
('Pedro Vilcapaza', 'IE008', 'Juliaca');

-- ==========================================
-- 12. REGISTRO DE LOGOTIPOS DE EJEMPLO
-- Los emblemas aún no entregados usan un distintivo temporal.
-- Los escudos reales de Perú Birf, Politécnico, Comercio 32, Encinas, INA 91, José María Arguedas, Las Mercedes y Vilcapaza están en public/uploads/.
-- ==========================================

INSERT INTO logotipos
(id_institucion, nombre, imagen, categoria, tipo, puntaje)
VALUES
(1, 'Perú Birf', 'uploads/peru-birf.png', 'COMUN', 'POSITIVO', 10),
(2, 'Politécnico', 'uploads/politecnico.png', 'ESPECIAL', 'POSITIVO', 25),
(3, 'José Antonio Encinas', 'uploads/encinas.png', 'DORADO', 'POSITIVO', 50),
(4, 'Las Mercedes', 'uploads/mercedes.png', 'COMUN', 'POSITIVO', 10),
(5, 'Comercio 32', 'uploads/comercio32.png', 'LEGENDARIO', 'POSITIVO', 100),
(6, 'INA 91', 'uploads/ina91.png', 'CONTAMINADO', 'NEGATIVO', -10),
(7, 'José María Arguedas', 'uploads/jose-maria-arguedas.png', 'PELIGROSO', 'NEGATIVO', -25),
(8, 'Pedro Vilcapaza', 'uploads/vilcapaza.png', 'PENALIZACION', 'NEGATIVO', -50);

-- ==========================================
-- 13. REGISTRO DE NIVELES
-- ==========================================

INSERT INTO niveles
(numero_nivel, nombre, puntaje_objetivo, velocidad_caida,
 frecuencia_logotipos, cantidad_maxima_logotipos, dificultad)
VALUES
(1, 'Principiante', 100, 1.00, 1500, 5, 'FACIL'),
(2, 'Aprendiz', 250, 1.30, 1200, 7, 'FACIL'),
(3, 'Intermedio', 500, 1.60, 1000, 9, 'MEDIO'),
(4, 'Avanzado', 800, 2.00, 800, 12, 'DIFICIL'),
(5, 'Experto', 1200, 2.50, 600, 15, 'EXTREMO'),
(6, 'Terminator', 2000, 3.00, 450, 20, 'EXTREMO');

-- ==========================================
-- 14. CONFIGURACION INICIAL
-- ==========================================

INSERT INTO configuracion
(nombre_juego, tiempo_partida, velocidad_base,
 dificultad_general, sonido_activo, pantalla_completa)
VALUES
('LOGO HUNTER - TERMINATOR EDITION',
 120, 1.00, 'MEDIO', TRUE, TRUE);

-- ==========================================
-- 15. VISTA: RANKING GENERAL
-- ==========================================

CREATE VIEW vista_ranking AS
SELECT
    u.id_usuario,
    u.nombre_usuario,
    u.nombres,
    u.apellidos,
    i.nombre AS institucion,
    MAX(p.puntaje_final) AS mejor_puntaje,
    MAX(p.nivel_alcanzado) AS nivel_maximo,
    COUNT(p.id_partida) AS total_partidas
FROM usuarios u
LEFT JOIN instituciones i
ON u.id_institucion = i.id_institucion
LEFT JOIN partidas p
ON u.id_usuario = p.id_usuario
GROUP BY
    u.id_usuario,
    u.nombre_usuario,
    u.nombres,
    u.apellidos,
    i.nombre;

-- ==========================================
-- FIN DE LA BASE DE DATOS
-- ==========================================

SELECT 'BASE DE DATOS LOGO HUNTER CREADA CORRECTAMENTE'
AS mensaje;
-- Ver todas las instituciones
SELECT * FROM instituciones;

-- Ver todos los logotipos
SELECT * FROM logotipos;

-- Ver los niveles
SELECT * FROM niveles;

-- Consultar ranking
SELECT * FROM vista_ranking
ORDER BY mejor_puntaje DESC
LIMIT 10;

-- Consultar partidas
SELECT * FROM partidas;

-- Consultar estudiantes
SELECT * FROM usuarios;

USE logo_hunter_db;

CREATE TABLE top_10_jugadores (
    id_top INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL UNIQUE,
    puntaje_maximo INT NOT NULL DEFAULT 0,
    nivel_alcanzado INT NOT NULL DEFAULT 1,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

SELECT
    ROW_NUMBER() OVER (
        ORDER BY puntaje_maximo DESC
    ) AS posicion,
    u.nombres,
    u.apellidos,
    u.nombre_usuario,
    i.nombre AS institucion,
    t.puntaje_maximo,
    t.nivel_alcanzado
FROM top_10_jugadores t
INNER JOIN usuarios u
    ON t.id_usuario = u.id_usuario
LEFT JOIN instituciones i
    ON u.id_institucion = i.id_institucion
ORDER BY t.puntaje_maximo DESC
LIMIT 10;

DELIMITER //

CREATE PROCEDURE actualizar_top_10()
BEGIN
    DELETE FROM top_10_jugadores;

    INSERT INTO top_10_jugadores
    (id_usuario, puntaje_maximo, nivel_alcanzado)

    SELECT
        id_usuario,
        MAX(puntaje_final),
        MAX(nivel_alcanzado)
    FROM partidas
    GROUP BY id_usuario
    ORDER BY MAX(puntaje_final) DESC
    LIMIT 10;
END //

DELIMITER ;

-- Ejecutar actualización
CALL actualizar_top_10();
